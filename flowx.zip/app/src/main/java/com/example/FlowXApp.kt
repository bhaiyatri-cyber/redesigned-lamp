package com.example

import android.app.Application
import androidx.room.Room
import com.example.data.local.ChatDatabase
import com.example.data.repository.ChatRepository

class FlowXApp : Application() {
    
    lateinit var database: ChatDatabase
        private set
        
    lateinit var repository: ChatRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            this,
            ChatDatabase::class.java,
            "flowx_database"
        ).build()
        
        repository = ChatRepository(database.chatDao())
    }
}
