package com.example.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class ChatMessageDto(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
    val model: String = "meta/llama-3.1-70b-instruct",
    val messages: List<ChatMessageDto>,
    val max_tokens: Int = 1024,
    val temperature: Double = 0.5,
    val top_p: Double = 1.0,
    val stream: Boolean = false
)

@JsonClass(generateAdapter = true)
data class ChatCompletionResponse(
    val id: String,
    val choices: List<ChoiceDto>
)

@JsonClass(generateAdapter = true)
data class ChoiceDto(
    val index: Int,
    val message: ChatMessageDto,
    val finish_reason: String?
)

interface ApiService {
    @POST("chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: ChatCompletionRequest
    ): ChatCompletionResponse
}
