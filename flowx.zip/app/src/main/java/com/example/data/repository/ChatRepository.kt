package com.example.data.repository

import com.example.BuildConfig
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.remote.ApiService
import com.example.data.remote.ChatCompletionRequest
import com.example.data.remote.ChatMessageDto
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class ChatRepository(private val chatDao: ChatDao) {

    private val apiService: ApiService

    init {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://integrate.api.nvidia.com/v1/")
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        apiService = retrofit.create(ApiService::class.java)
    }

    // --- DB Operations ---
    
    fun getAllSessions(): Flow<List<ChatSession>> = chatDao.getAllSessions()
    
    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessage>> = chatDao.getMessagesForSession(sessionId)
    
    suspend fun createNewSession(title: String): Long {
        return chatDao.insertSession(ChatSession(title = title, snippet = "New Chat"))
    }
    
    suspend fun deleteSession(sessionId: Long) {
        chatDao.deleteSessionAndMessages(sessionId)
    }

    // --- Network & AI Logic ---

    suspend fun sendMessage(sessionId: Long, userMessage: String) {
        // 1. Save User Message
        val timestamp = System.currentTimeMillis()
        chatDao.insertMessage(
            ChatMessage(
                sessionId = sessionId,
                role = "user",
                content = userMessage,
                timestamp = timestamp
            )
        )
        // Update session snippet
        val shortSnippet = if (userMessage.length > 50) userMessage.take(47) + "..." else userMessage
        chatDao.updateSessionSnippet(sessionId, title = shortSnippet, snippet = shortSnippet, timestamp = timestamp)

        // 2. Fetch history for context
        val history = chatDao.getMessagesSnapshot(sessionId)
        val contextMessages = history.map { 
            val role = if (it.role == "user") "user" else "assistant"
            ChatMessageDto(role = role, content = it.content) 
        }

        val apiKey = BuildConfig.NV_API_KEY.takeIf { it.isNotEmpty() } ?: BuildConfig.GEMINI_API_KEY
        
        if (apiKey.isEmpty() || apiKey.startsWith("MY_")) {
            // Simulated fallback if no API key is provided
            chatDao.insertMessage(
                ChatMessage(
                    sessionId = sessionId,
                    role = "assistant",
                    content = "Please configure your API Key in Settings or via Secrets panel."
                )
            )
            return
        }

        try {
            val request = ChatCompletionRequest(
                messages = contextMessages
            )
            
            val response = apiService.createChatCompletion(
                authHeader = "Bearer $apiKey",
                request = request
            )
            
            val aiReply = response.choices.firstOrNull()?.message?.content ?: "No response"
            
            chatDao.insertMessage(
                ChatMessage(
                    sessionId = sessionId,
                    role = "assistant",
                    content = aiReply
                )
            )
            
            val aiSnippet = if (aiReply.length > 50) aiReply.take(47) + "..." else aiReply
            chatDao.updateSessionSnippet(sessionId, title = shortSnippet, snippet = aiSnippet)
            
        } catch (e: Exception) {
            e.printStackTrace()
            chatDao.insertMessage(
                ChatMessage(
                    sessionId = sessionId,
                    role = "assistant",
                    content = "Error: ${e.localizedMessage}"
                )
            )
        }
    }
}
