package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF6C63FF),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF03DAC6),
    onSecondary = Color(0xFF000000),
    tertiary = Color(0xFFBB86FC),
    background = Color(0xFF0D0D12),
    onBackground = Color(0xFFE2E2E9),
    surface = Color(0xFF161622),
    onSurface = Color(0xFFE2E2E9),
    surfaceVariant = Color(0xFF232336),
    onSurfaceVariant = Color(0xFFC4C4D4)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark mode for premium feel
  dynamicColor: Boolean = false, // Disable dynamic to keep the brand identity
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
