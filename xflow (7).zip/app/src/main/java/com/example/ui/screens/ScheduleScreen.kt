package com.example.ui.screens
import com.example.engine.XFlowEngine

import android.app.TimePickerDialog
import java.util.Calendar
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.data.Schedule
import com.example.ui.theme.Accent
import com.example.ui.theme.Background
import com.example.ui.theme.Surface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.BorderColor
import com.example.ui.theme.TextTertiary
import androidx.compose.foundation.border
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppInfo(val name: String, val packageName: String, val icon: Drawable?)

fun drawableToBitmap(drawable: Drawable?): androidx.compose.ui.graphics.ImageBitmap? {
    if (drawable == null) return null
    if (drawable is BitmapDrawable) return drawable.bitmap.asImageBitmap()
    val width = if (drawable.intrinsicWidth <= 0) 100 else drawable.intrinsicWidth
    val height = if (drawable.intrinsicHeight <= 0) 100 else drawable.intrinsicHeight
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap.asImageBitmap()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AppDatabase.getDatabase(context) }

    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var timeMinutes by remember { mutableStateOf("25") }
    var isOnlineMode by remember { mutableStateOf(false) }
    
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    var showAppPicker by remember { mutableStateOf(false) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    
    var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var scheduleMode by remember { mutableStateOf("Duration") }
    var startHour by remember { mutableStateOf(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) }
    var startMinute by remember { mutableStateOf(Calendar.getInstance().get(Calendar.MINUTE)) }
    var endHour by remember { mutableStateOf((Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1) % 24) }
    var endMinute by remember { mutableStateOf(Calendar.getInstance().get(Calendar.MINUTE)) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val filtered = packages.filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                .map {
                    AppInfo(
                        name = it.loadLabel(pm).toString(),
                        packageName = it.packageName,
                        icon = it.loadIcon(pm)
                    )
                }
                .sortedBy { it.name }
            appsList = filtered
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New Schedule", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Background,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("Subject") },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Schedule Mode: ", color = TextPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = scheduleMode == "Duration",
                    onClick = { scheduleMode = "Duration" },
                    label = { Text("Duration") }
                )
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = scheduleMode == "Exact",
                    onClick = { scheduleMode = "Exact" },
                    label = { Text("Exact Time") }
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            if (scheduleMode == "Duration") {
                OutlinedTextField(
                    value = timeMinutes,
                    onValueChange = { timeMinutes = it },
                    label = { Text("Time (Minutes)") },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m -> startHour = h; startMinute = m }, startHour, startMinute, false).show()
                    }, modifier = Modifier.weight(1f)) {
                        val amPm = if (startHour >= 12) "PM" else "AM"
                        val h12 = if (startHour % 12 == 0) 12 else startHour % 12
                        Text("Start: ${String.format("%02d:%02d", h12, startMinute)} $amPm")
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m -> endHour = h; endMinute = m }, endHour, endMinute, false).show()
                    }, modifier = Modifier.weight(1f)) {
                        val amPm = if (endHour >= 12) "PM" else "AM"
                        val h12 = if (endHour % 12 == 0) 12 else endHour % 12
                        Text("End: ${String.format("%02d:%02d", h12, endMinute)} $amPm")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mode: ", color = TextPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = !isOnlineMode,
                    onClick = { isOnlineMode = false },
                    label = { Text("Offline") }
                )
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = isOnlineMode,
                    onClick = { isOnlineMode = true },
                    label = { Text("Online") }
                )
            }
            if (isOnlineMode) {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Surface)
                        .clickable { showAppPicker = true }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (selectedApp != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val bitmap = remember(selectedApp) { drawableToBitmap(selectedApp?.icon) }
                                if (bitmap != null) {
                                    Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                                Column {
                                    Text(selectedApp!!.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(selectedApp!!.packageName, color = TextSecondary, fontSize = 12.sp)
                                }
                            }
                        } else {
                            Text("Select Target App", color = TextSecondary)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Surface)
                    .border(1.dp, BorderColor, RoundedCornerShape(24.dp))
                    .padding(24.dp)
            ) {
                Column {
                    Text("LIVE PREVIEW", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val displaySubject = subject.ifBlank { "No Subject" }
                    Text(displaySubject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("MODE", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(if (scheduleMode == "Exact") "Exact Time" else "Duration", fontSize = 14.sp, color = TextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("STUDY", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(if (isOnlineMode) "Online" else "Offline", fontSize = 14.sp, color = Accent)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("TIME", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            if (scheduleMode == "Exact") {
                                val sAmPm = if (startHour >= 12) "PM" else "AM"
                                val sH12 = if (startHour % 12 == 0) 12 else startHour % 12
                                val eAmPm = if (endHour >= 12) "PM" else "AM"
                                val eH12 = if (endHour % 12 == 0) 12 else endHour % 12
                                Text("${String.format("%02d:%02d", sH12, startMinute)} $sAmPm → ${String.format("%02d:%02d", eH12, endMinute)} $eAmPm", fontSize = 14.sp, color = TextPrimary)
                            } else {
                                Text("${timeMinutes.toLongOrNull() ?: 0} Minutes", fontSize = 14.sp, color = TextPrimary)
                            }
                        }
                        if (isOnlineMode && selectedApp != null) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("APP", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(selectedApp!!.name, fontSize = 14.sp, color = TextPrimary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            Button(
                onClick = {
                    val hasUsage = XFlowEngine.checkUsageAccess(context)
                    val hasNotif = XFlowEngine.checkNotification(context)
                    val hasBattery = XFlowEngine.checkBatteryOpt(context)
                    val hasForeground = XFlowEngine.checkForegroundService(context)
                    
                    val todayStart = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, startHour)
                        set(Calendar.MINUTE, startMinute)
                        set(Calendar.SECOND, 0)
                    }.timeInMillis
                    val todayEnd = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, endHour)
                        set(Calendar.MINUTE, endMinute)
                        set(Calendar.SECOND, 0)
                    }.timeInMillis

                    if (subject.isBlank()) {
                        errorMessage = "Subject is required"
                    } else if (scheduleMode == "Duration" && timeMinutes.toLongOrNull()?.let { it > 0 } != true) {
                        errorMessage = "Valid time in minutes is required"
                    } else if (scheduleMode == "Exact" && todayEnd <= todayStart) {
                        errorMessage = "End Time must be after Start Time"
                    } else if (isOnlineMode && selectedApp == null) {
                        errorMessage = "Target app is required for Online mode"
                    } else if ((isOnlineMode && !hasUsage) || !hasNotif || !hasBattery || !hasForeground) {
                        showPermissionDialog = true
                    } else {
                        errorMessage = null
                        saveSchedule(subject, description, scheduleMode, timeMinutes, todayStart, todayEnd, isOnlineMode, selectedApp, db, scope, navController)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = androidx.compose.ui.graphics.Color.Black)
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showAppPicker) {
        Dialog(onDismissRequest = { showAppPicker = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Background,
                modifier = Modifier.fillMaxHeight(0.8f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select App", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    LazyColumn {
                        items(appsList) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedApp = app
                                        showAppPicker = false
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val bitmap = remember(app) { drawableToBitmap(app.icon) }
                                if (bitmap != null) {
                                    Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                                Column {
                                    Text(app.name, color = TextPrimary)
                                    Text(app.packageName, color = TextSecondary, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Permissions Required") },
            text = { Text("You need to grant required permissions in Settings before creating this schedule.") },
            confirmButton = {
                TextButton(onClick = { 
                    showPermissionDialog = false
                    navController.navigate("settings")
                }) {
                    Text("Go to Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun saveSchedule(
    subject: String,
    description: String,
    scheduleMode: String,
    timeMinutes: String,
    startTimeMillis: Long,
    endTimeMillis: Long,
    isOnlineMode: Boolean,
    selectedApp: AppInfo?,

    db: AppDatabase,
    scope: kotlinx.coroutines.CoroutineScope,
    navController: NavController
) {
    val totalSeconds = if (scheduleMode == "Exact") {
        (endTimeMillis - startTimeMillis) / 1000
    } else {
        (timeMinutes.toLongOrNull() ?: 25L) * 60
    }

    val schedule = Schedule(
        subject = subject,
        description = description,
        totalTimeSeconds = totalSeconds,
        isOnlineMode = isOnlineMode,
        targetAppPackage = if (isOnlineMode) selectedApp?.packageName else null,
        scheduleMode = scheduleMode,
        startTimeMillis = if (scheduleMode == "Exact") startTimeMillis else 0L,
        endTimeMillis = if (scheduleMode == "Exact") endTimeMillis else 0L

    )
    scope.launch {
        db.scheduleDao().insertSchedule(schedule)
        navController.popBackStack()
    }
}

