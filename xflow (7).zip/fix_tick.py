with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_tick_else = """        } else {
            if (now >= currentActive.endTimeMillis) {
                stopSchedule()
            } else {
                if (currentActive.scheduleMode == "Exact" && now >= currentActive.startTimeMillis && currentActive.status == "Upcoming") {
                    val updated = currentActive.copy(status = "Waiting")
                    _activeSchedule.value = updated
                    CoroutineScope(Dispatchers.IO).launch { scheduleDao.updateSchedule(updated) }
                }
                if (_timeRemainingSeconds.value <= 0) {
                    stopSchedule()
                }
            }
            checkConditionsAndToggleTimer()
        }"""

new_tick_else = """        } else {
            if (currentActive.scheduleMode == "Exact" && now >= currentActive.endTimeMillis) {
                stopSchedule()
            } else if (currentActive.scheduleMode == "Duration" && _timeRemainingSeconds.value <= 0) {
                stopSchedule()
            } else {
                if (currentActive.scheduleMode == "Exact" && now >= currentActive.startTimeMillis && currentActive.status == "Upcoming") {
                    val updated = currentActive.copy(status = "Waiting")
                    _activeSchedule.value = updated
                    CoroutineScope(Dispatchers.IO).launch { scheduleDao.updateSchedule(updated) }
                }
            }
            checkConditionsAndToggleTimer()
        }"""

content = content.replace(old_tick_else, new_tick_else)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
print("Fixed tick!")
