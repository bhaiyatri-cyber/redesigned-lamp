with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_check = """                if (now >= schedule.endTimeMillis) {"""
new_check = """                if (schedule.endTimeMillis > 0L && now >= schedule.endTimeMillis) {"""

content = content.replace(old_check, new_check)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
