with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

import re

# We will just replace Text -> AutoSizeText for the LIVE TIMER text in ScheduleCard
old_timer_text = 'Text(formatTimeFull(currentCompletedSeconds), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary)'
new_timer_text = 'AutoSizeText(formatTimeFull(currentCompletedSeconds), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary, maxLines = 1)'
content = content.replace(old_timer_text, new_timer_text)

old_timer_text_2 = 'Text(formatTimeFull(schedule.timeCompletedSeconds), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary)'
new_timer_text_2 = 'AutoSizeText(formatTimeFull(schedule.timeCompletedSeconds), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary, maxLines = 1)'
content = content.replace(old_timer_text_2, new_timer_text_2)

# Also fix the Subject to use maxLines and ellipsis
old_subject_text = 'Text(schedule.subject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)'
new_subject_text = 'Text(schedule.subject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_subject_text, new_subject_text)

old_desc_text = 'Text(schedule.description, fontSize = 14.sp, color = TextSecondary)'
new_desc_text = 'Text(schedule.description, fontSize = 14.sp, color = TextSecondary, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_desc_text, new_desc_text)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
