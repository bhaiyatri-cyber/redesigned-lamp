with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_cond = """        var timeValid = true
        
        if (now < schedule.startTimeMillis || now >= schedule.endTimeMillis) {
            timeValid = false
        }"""

new_cond = """        var timeValid = true
        
        if (schedule.scheduleMode == "Exact") {
            if (now < schedule.startTimeMillis || now >= schedule.endTimeMillis) {
                timeValid = false
            }
        }"""

content = content.replace(old_cond, new_cond)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
print("Fixed cond!")
