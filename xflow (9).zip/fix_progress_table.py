with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

old_table = """            analytics.forEach { stat ->
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stat.subject, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("${formatTime(stat.time)}", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(60.dp))
                    Text("${stat.avgComp}%", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(40.dp))
                    Text("${stat.sessions}x", color = Accent, fontSize = 12.sp, modifier = Modifier.width(30.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                }
                HorizontalDivider(color = BorderColorLight)
            }"""

new_table = """            analytics.forEach { stat ->
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stat.subject, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${formatTime(stat.time)}", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(0.4f), textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 1)
                    Text("${stat.avgComp}%", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(0.3f), textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 1)
                    Text("${stat.sessions}x", color = Accent, fontSize = 12.sp, modifier = Modifier.weight(0.2f), textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 1)
                }
                HorizontalDivider(color = BorderColorLight)
            }"""

content = content.replace(old_table, new_table)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
