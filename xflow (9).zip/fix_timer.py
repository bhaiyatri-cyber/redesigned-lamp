with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

old_remaining = """                DetailRow("Studied", "${compMins}m")
                DetailRow("Remaining", "${remainingSecs / 60}m")
                DetailRow("Completion", "$percent%")"""

new_remaining = """                DetailRow("Studied", "${compMins}m")
                if (isActive) {
                    val hrs = remainingSecs / 3600
                    val mins = (remainingSecs % 3600) / 60
                    val secs = remainingSecs % 60
                    val timeStr = if (hrs > 0) String.format("%02d:%02d:%02d", hrs, mins, secs) else String.format("%02d:%02d", mins, secs)
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Live Timer", fontSize = 16.sp, color = TextSecondary)
                        Text(timeStr, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)
                    }
                } else {
                    DetailRow("Remaining", "${remainingSecs / 60}m")
                }
                DetailRow("Completion", "$percent%")"""

content = content.replace(old_remaining, new_remaining)
with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
