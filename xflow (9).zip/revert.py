import os
import re

def revert_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()

    # 1. Revert Dimensions to fixed dp
    content = content.replace('Dimensions.paddingMedium', '24.dp')
    content = content.replace('Dimensions.paddingLarge', '32.dp')
    content = content.replace('Dimensions.paddingSmall', '16.dp')
    
    # 2. Revert defaultMinSize to height
    content = content.replace('.defaultMinSize(minHeight = 56.dp)', '.height(56.dp)')
    
    # 3. Revert AutoSizeText to Text
    content = content.replace('AutoSizeText(', 'Text(')
    content = content.replace('import com.example.ui.components.AutoSizeText', '')
    content = content.replace('import com.example.ui.theme.Dimensions', '')

    # 4. Remove maxLines and overflow from Text()
    # It might be safer to remove specific additions like `maxLines = \d+`, `overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis`
    content = re.sub(r',\s*maxLines\s*=\s*\d+', '', content)
    content = re.sub(r',\s*overflow\s*=\s*androidx\.compose\.ui\.text\.style\.TextOverflow\.Ellipsis', '', content)
    content = re.sub(r',\s*modifier\s*=\s*Modifier\.weight\([^)]*fill\s*=\s*false[^)]*\)', '', content)

    # Clean up empty lines or trailing commas if any were left by regex? The regex matches commas before it.

    with open(file_path, 'w') as f:
        f.write(content)

for root, _, files in os.walk('app/src/main/java/com/example/ui/screens'):
    for file in files:
        if file.endswith('.kt'):
            revert_file(os.path.join(root, file))

