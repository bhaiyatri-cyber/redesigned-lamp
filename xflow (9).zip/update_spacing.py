import os
import re

def update_spacing(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    if 'import com.example.ui.theme.Dimensions' not in content:
        content = content.replace('import com.example.ui.theme.*', 'import com.example.ui.theme.*\nimport com.example.ui.theme.Dimensions')

    # Replaces common paddings with dimensions
    content = re.sub(r'\.padding\(horizontal = 24\.dp\)', '.padding(horizontal = Dimensions.paddingMedium)', content)
    content = re.sub(r'\.padding\(24\.dp\)', '.padding(Dimensions.paddingMedium)', content)
    content = re.sub(r'Spacer\(modifier = Modifier\.height\(24\.dp\)\)', 'Spacer(modifier = Modifier.height(Dimensions.paddingMedium))', content)
    content = re.sub(r'Spacer\(modifier = Modifier\.height\(32\.dp\)\)', 'Spacer(modifier = Modifier.height(Dimensions.paddingLarge))', content)
    
    with open(file_path, 'w') as f:
        f.write(content)

for root, _, files in os.walk('app/src/main/java/com/example/ui/screens'):
    for file in files:
        if file.endswith('.kt'):
            update_spacing(os.path.join(root, file))
