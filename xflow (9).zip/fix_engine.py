with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

import re

# Add graceJob
if "private var graceJob: Job? = null" not in content:
    content = content.replace("private var timerJob: Job? = null", "private var timerJob: Job? = null\n    private var graceJob: Job? = null")

old_check = """        if (shouldRun && !_isTimerRunning.value) {
            resumeTimer()
        } else if (!shouldRun && _isTimerRunning.value) {
            pauseTimer()
        }"""

new_check = """        if (shouldRun) {
            graceJob?.cancel()
            if (!_isTimerRunning.value) {
                resumeTimer()
            }
        } else if (!shouldRun && _isTimerRunning.value) {
            if (!schedule.isOnlineMode) {
                if (graceJob?.isActive != true) {
                    graceJob = CoroutineScope(Dispatchers.Default).launch {
                        delay(10000)
                        pauseTimer()
                    }
                }
            } else {
                pauseTimer()
            }
        }"""

content = content.replace(old_check, new_check)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
print("Engine Fixed")
