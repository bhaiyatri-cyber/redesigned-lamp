with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

if 'import com.example.ui.components.AutoSizeText' not in content:
    content = content.replace('import androidx.compose.ui.Modifier', 'import androidx.compose.ui.Modifier\nimport com.example.ui.components.AutoSizeText')

old_stat_item = """@Composable
fun StatItem(label: String, value: String, valueColor: Color = TextPrimary, valueSize: androidx.compose.ui.unit.TextUnit = 20.sp) {
    Column {
        Text(label, fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, fontSize = valueSize, fontWeight = FontWeight.Medium, color = valueColor)
    }
}"""

new_stat_item = """@Composable
fun StatItem(label: String, value: String, valueColor: Color = TextPrimary, valueSize: androidx.compose.ui.unit.TextUnit = 20.sp) {
    Column {
        Text(label, fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        Spacer(modifier = Modifier.height(4.dp))
        AutoSizeText(value, fontSize = valueSize, fontWeight = FontWeight.Medium, color = valueColor, maxLines = 1)
    }
}"""

content = content.replace(old_stat_item, new_stat_item)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
