with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_stop = """    fun stopSchedule() {
        val current = _activeSchedule.value ?: return
        
        timerJob?.cancel()
        timerJob = null
        _isTimerRunning.value = false"""

new_stop = """    fun stopSchedule() {
        val current = _activeSchedule.value ?: return
        _activeSchedule.value = null
        
        timerJob?.cancel()
        timerJob = null
        _isTimerRunning.value = false"""

content = content.replace(old_stop, new_stop)

old_null = """        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(updatedSchedule)
        }
        _activeSchedule.value = null
    }"""

new_null = """        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(updatedSchedule)
        }
    }"""

content = content.replace(old_null, new_null)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)

