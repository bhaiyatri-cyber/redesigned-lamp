package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.engine.BackupManager
import com.example.engine.XFlowEngine
import com.example.ui.theme.*

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AppDatabase.getDatabase(context) }
    
    var showRestoreDialog by remember { mutableStateOf(false) }
    var selectedBackupUri by remember { mutableStateOf<Uri?>(null) }
    var backupInfo by remember { mutableStateOf<BackupManager.BackupInfo?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            isLoading = true
            scope.launch {
                try {
                    val schedules = XFlowEngine.getAllSchedulesOnce()
                    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                    val appVersion = packageInfo.versionName ?: "1.0"
                    
                    val jsonString = BackupManager.createBackupJson(schedules, appVersion)
                    val success = BackupManager.writeBackupToUri(context, uri, jsonString)
                    
                    withContext(Dispatchers.Main) {
                        isLoading = false
                        if (success) {
                            Toast.makeText(context, "Backup Exported Successfully", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Backup Failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        isLoading = false
                        Toast.makeText(context, "Backup Failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            isLoading = true
            scope.launch {
                val info = BackupManager.readBackupInfo(context, uri)
                withContext(Dispatchers.Main) {
                    isLoading = false
                    if (info != null) {
                        backupInfo = info
                        selectedBackupUri = uri
                        showRestoreDialog = true
                    } else {
                        Toast.makeText(context, "Restore Failed: Invalid Backup File", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Backup & Restore", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Background,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            Text(
                "Keep your study data safe. Export a local backup to your device storage, or restore from an existing backup. Everything works completely offline.",
                color = TextSecondary,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            BackupActionCard(
                title = "Export Backup",
                description = "Save your schedules, history, and progress to a local file.",
                icon = Icons.Default.Save,
                onClick = {
                    val dateFormat = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault())
                    val dateStr = dateFormat.format(java.util.Date())
                    createDocumentLauncher.launch("XFlow_Backup_$dateStr.json")
                }
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            BackupActionCard(
                title = "Restore Backup",
                description = "Import an existing backup to restore your data.",
                icon = Icons.Default.Restore,
                onClick = {
                    openDocumentLauncher.launch(arrayOf("application/json", "*/*"))
                }
            )
        }
        
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x80000000)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Accent)
            }
        }
    }

    if (showRestoreDialog && backupInfo != null && selectedBackupUri != null) {
        Dialog(onDismissRequest = { showRestoreDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("Restore Backup", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("This will replace your current local data.", color = Color(0xFFF44336), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Background)
                            .padding(16.dp)
                    ) {
                        InfoRow("Backup Name", backupInfo!!.backupName)
                        InfoRow("Backup Date", backupInfo!!.backupDate)
                        InfoRow("App Version", backupInfo!!.appVersion)
                        InfoRow("Database Version", backupInfo!!.databaseVersion.toString())
                        InfoRow("Backup Size", "${backupInfo!!.backupSize / 1024} KB")
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showRestoreDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = {
                                val uri = selectedBackupUri!!
                                showRestoreDialog = false
                                isLoading = true
                                scope.launch {
                                    try {
                                        val schedules = BackupManager.readSchedulesFromUri(context, uri)
                                        if (schedules != null) {
                                            XFlowEngine.restoreBackup(schedules)
                                            withContext(Dispatchers.Main) {
                                                isLoading = false
                                                Toast.makeText(context, "Data Restored Successfully", Toast.LENGTH_SHORT).show()
                                                navController.navigate("home") {
                                                    popUpTo(0) { inclusive = true }
                                                }
                                            }
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                isLoading = false
                                                Toast.makeText(context, "Restore Failed: Corrupted Backup", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                        withContext(Dispatchers.Main) {
                                            isLoading = false
                                            Toast.makeText(context, "Restore Failed", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
                        ) {
                            Text("Restore", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 14.sp)
        Text(value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BackupActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColorLight)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Background),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = Accent, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(title, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(description, color = TextSecondary, fontSize = 14.sp)
            }
        }
    }
}
