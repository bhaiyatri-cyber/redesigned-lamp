package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.data.Schedule
import com.example.ui.theme.*

import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(navController: NavController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    
    val allSchedules by db.scheduleDao().getAllSchedules().collectAsState(initial = emptyList())
    val historyItems = allSchedules.filter { it.status !in listOf("Upcoming", "Waiting", "Running", "Paused") }
    
    val now = System.currentTimeMillis()
    val todayStart = remember(now) { getStartOfDay(now) }
    val weekStart = remember(now) { getStartOfWeek(now) }
    val monthStart = remember(now) { getStartOfMonth(now) }
    
    val todayItems = historyItems.filter { it.createdAt >= todayStart }
    val weekItems = historyItems.filter { it.createdAt >= weekStart }
    val monthItems = historyItems.filter { it.createdAt >= monthStart }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Progress", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Background,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = Background
    ) { padding ->
        if (historyItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Surface)
                    .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("No study data available.", color = TextSecondary, fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { TodayCard(todayItems) }
                item { LifetimeCard(historyItems) }
                
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Box(modifier = Modifier.weight(1f)) { WeeklyCard(weekItems) }
                        Box(modifier = Modifier.weight(1f)) { MonthlyCard(monthItems) }
                    }
                }
                
                item { PerformanceSummary(historyItems) }
                item { SubjectAnalytics(historyItems) }
                item { DailyChartCard(historyItems, todayStart) }
                item { WeeklyChartCard(historyItems, weekStart) }
                item { MonthlyChartCard(historyItems, monthStart) }
            }
        }
    }
}

fun getStartOfDay(timeInMillis: Long): Long {
    return Calendar.getInstance().apply {
        this.timeInMillis = timeInMillis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

fun getStartOfWeek(timeInMillis: Long): Long {
    return Calendar.getInstance().apply {
        this.timeInMillis = timeInMillis
        firstDayOfWeek = Calendar.MONDAY
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

fun getStartOfMonth(timeInMillis: Long): Long {
    return Calendar.getInstance().apply {
        this.timeInMillis = timeInMillis
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

fun formatTime(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    return if (hrs > 0) "${hrs}h ${mins}m" else "${mins}m"
}

fun calculateCompletionAvg(items: List<Schedule>): Int {
    if (items.isEmpty()) return 0
    var totalPercent = 0f
    for (item in items) {
        if (item.totalTimeSeconds > 0) {
            totalPercent += (item.timeCompletedSeconds.toFloat() / item.totalTimeSeconds * 100)
        }
    }
    return (totalPercent / items.size).toInt()
}

@Composable
fun TodayCard(items: List<Schedule>) {
    val studyTime = items.sumOf { it.timeCompletedSeconds }
    val sessions = items.size
    val completionAvg = calculateCompletionAvg(items)
    
    val perf = when {
        completionAvg >= 90 -> "Excellent"
        completionAvg >= 75 -> "Great"
        completionAvg >= 50 -> "Good"
        completionAvg >= 25 -> "Fair"
        sessions > 0 -> "Needs Work"
        else -> "None"
    }

    DashboardCard(title = "Today") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Study Time", value = formatTime(studyTime))
            StatItem(label = "Sessions", value = sessions.toString())
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Completion", value = "$completionAvg%")
            StatItem(label = "Performance", value = perf)
        }
    }
}

@Composable
fun LifetimeCard(items: List<Schedule>) {
    val studyTime = items.sumOf { it.timeCompletedSeconds }
    val sessions = items.size
    val completed = items.count { it.status == "Completed" }
    val partial = items.count { it.status in listOf("Almost Completed", "Good Progress", "Partial Progress", "Low Progress") }
    val missed = items.count { it.status == "Missed" }

    DashboardCard(title = "Lifetime Progress") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Total Time", value = formatTime(studyTime))
            StatItem(label = "Total Sessions", value = sessions.toString())
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Completed", value = completed.toString(), valueColor = Color(0xFF4CAF50))
            StatItem(label = "Partial", value = partial.toString(), valueColor = Accent)
            StatItem(label = "Missed", value = missed.toString(), valueColor = Color(0xFFF44336))
        }
    }
}

@Composable
fun WeeklyCard(items: List<Schedule>) {
    val studyTime = items.sumOf { it.timeCompletedSeconds }
    val sessions = items.size
    val completionAvg = calculateCompletionAvg(items)

    DashboardCard(title = "This Week") {
        StatItem(label = "Time", value = formatTime(studyTime))
        Spacer(modifier = Modifier.height(12.dp))
        StatItem(label = "Sessions", value = sessions.toString())
        Spacer(modifier = Modifier.height(12.dp))
        StatItem(label = "Completion", value = "$completionAvg%")
    }
}

@Composable
fun MonthlyCard(items: List<Schedule>) {
    val studyTime = items.sumOf { it.timeCompletedSeconds }
    val sessions = items.size
    val completionAvg = calculateCompletionAvg(items)
    val perf = when {
        completionAvg >= 75 -> "High"
        completionAvg >= 50 -> "Med"
        sessions > 0 -> "Low"
        else -> "None"
    }

    DashboardCard(title = "This Month") {
        StatItem(label = "Time", value = formatTime(studyTime))
        Spacer(modifier = Modifier.height(12.dp))
        StatItem(label = "Sessions", value = sessions.toString())
        Spacer(modifier = Modifier.height(12.dp))
        StatItem(label = "Perf", value = perf)
    }
}

@Composable
fun SubjectAnalytics(items: List<Schedule>) {
    val subjectMap = items.groupBy { it.subject }
    val analytics = subjectMap.map { (subject, schedules) ->
        val time = schedules.sumOf { it.timeCompletedSeconds }
        val avgComp = calculateCompletionAvg(schedules)
        val sessions = schedules.size
        SubjectStat(subject, time, avgComp, sessions)
    }.sortedByDescending { it.time }

    DashboardCard(title = "Subject Analytics") {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            analytics.forEach { stat ->
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stat.subject, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("${formatTime(stat.time)}", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(60.dp))
                    Text("${stat.avgComp}%", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(40.dp))
                    Text("${stat.sessions}x", color = Accent, fontSize = 12.sp, modifier = Modifier.width(30.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                }
                HorizontalDivider(color = BorderColorLight)
            }
        }
    }
}

data class SubjectStat(val subject: String, val time: Long, val avgComp: Int, val sessions: Int)

@Composable
fun PerformanceSummary(items: List<Schedule>) {
    val subjectMap = items.groupBy { it.subject }
    val analytics = subjectMap.map { (subject, schedules) ->
        SubjectStat(subject, schedules.sumOf { it.timeCompletedSeconds }, calculateCompletionAvg(schedules), schedules.size)
    }
    
    val bestSubject = analytics.maxByOrNull { it.avgComp }?.subject ?: "N/A"
    val mostStudied = analytics.maxByOrNull { it.time }?.subject ?: "N/A"
    val overallComp = calculateCompletionAvg(items)
    val avgTime = if (items.isNotEmpty()) formatTime(items.sumOf { it.timeCompletedSeconds } / items.size) else "0m"

    DashboardCard(title = "Performance Summary") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Best Subject", value = bestSubject, valueSize = 14.sp)
            StatItem(label = "Most Studied", value = mostStudied, valueSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatItem(label = "Avg Completion", value = "$overallComp%")
            StatItem(label = "Avg Session Time", value = avgTime)
        }
    }
}

@Composable
fun DailyChartCard(items: List<Schedule>, todayStart: Long) {
    // Generate data for the last 7 days
    val daysData = (6 downTo 0).map { dayOffset ->
        val startOfDay = todayStart - (dayOffset * 24 * 60 * 60 * 1000L)
        val endOfDay = startOfDay + (24 * 60 * 60 * 1000L)
        
        val dayItems = items.filter { it.createdAt in startOfDay until endOfDay }
        val totalSeconds = dayItems.sumOf { it.timeCompletedSeconds }
        val hours = totalSeconds / 3600f
        
        val cal = Calendar.getInstance().apply { timeInMillis = startOfDay }
        val dayLabel = when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SUNDAY -> "S"
            Calendar.MONDAY -> "M"
            Calendar.TUESDAY -> "T"
            Calendar.WEDNESDAY -> "W"
            Calendar.THURSDAY -> "T"
            Calendar.FRIDAY -> "F"
            Calendar.SATURDAY -> "S"
            else -> ""
        }
        dayLabel to hours
    }
    
    val maxHours = daysData.maxOfOrNull { it.second }?.coerceAtLeast(1f) ?: 1f
    
    DashboardCard(title = "Daily Progress (Last 7 Days)") {
        Row(
            modifier = Modifier.fillMaxWidth().height(150.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            daysData.forEach { (label, hours) ->
                val fraction = hours / maxHours
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text(String.format("%.1f", hours), fontSize = 10.sp, color = TextTertiary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(24.dp)
                            .height((100 * fraction).dp.coerceAtLeast(4.dp))
                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            .background(Accent)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(label, fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}


@Composable
fun WeeklyChartCard(items: List<Schedule>, weekStart: Long) {
    val weeksData = (3 downTo 0).map { weekOffset ->
        val startOfWeek = weekStart - (weekOffset * 7 * 24 * 60 * 60 * 1000L)
        val endOfWeek = startOfWeek + (7 * 24 * 60 * 60 * 1000L)
        val weekItems = items.filter { it.createdAt in startOfWeek until endOfWeek }
        val hours = weekItems.sumOf { it.timeCompletedSeconds } / 3600f
        val label = if (weekOffset == 0) "This" else "${weekOffset}w"
        label to hours
    }
    val maxHours = weeksData.maxOfOrNull { it.second }?.coerceAtLeast(1f) ?: 1f
    
    DashboardCard(title = "Weekly Progress (Last 4 Weeks)") {
        Row(
            modifier = Modifier.fillMaxWidth().height(150.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            weeksData.forEach { (label, hours) ->
                val fraction = hours / maxHours
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f)) {
                    Text(String.format("%.1f", hours), fontSize = 10.sp, color = TextTertiary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(32.dp)
                            .height((100 * fraction).dp.coerceAtLeast(4.dp))
                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            .background(Accent)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(label, fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun MonthlyChartCard(items: List<Schedule>, monthStart: Long) {
    val monthsData = (5 downTo 0).map { monthOffset ->
        val cal = Calendar.getInstance().apply { 
            timeInMillis = monthStart 
            add(Calendar.MONTH, -monthOffset)
        }
        val startOfMonth = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val endOfMonth = cal.timeInMillis
        val monthItems = items.filter { it.createdAt in startOfMonth until endOfMonth }
        val hours = monthItems.sumOf { it.timeCompletedSeconds } / 3600f
        
        cal.timeInMillis = startOfMonth
        val label = when(cal.get(Calendar.MONTH)) {
            Calendar.JANUARY -> "Jan"
            Calendar.FEBRUARY -> "Feb"
            Calendar.MARCH -> "Mar"
            Calendar.APRIL -> "Apr"
            Calendar.MAY -> "May"
            Calendar.JUNE -> "Jun"
            Calendar.JULY -> "Jul"
            Calendar.AUGUST -> "Aug"
            Calendar.SEPTEMBER -> "Sep"
            Calendar.OCTOBER -> "Oct"
            Calendar.NOVEMBER -> "Nov"
            Calendar.DECEMBER -> "Dec"
            else -> ""
        }
        label to hours
    }
    val maxHours = monthsData.maxOfOrNull { it.second }?.coerceAtLeast(1f) ?: 1f
    
    DashboardCard(title = "Monthly Progress (Last 6 Months)") {
        Row(
            modifier = Modifier.fillMaxWidth().height(150.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            monthsData.forEach { (label, hours) ->
                val fraction = hours / maxHours
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f)) {
                    Text(String.format("%.1f", hours), fontSize = 10.sp, color = TextTertiary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(24.dp)
                            .height((100 * fraction).dp.coerceAtLeast(4.dp))
                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            .background(Accent)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(label, fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun DashboardCard(title: String, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Surface)
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(16.dp))
            content()
        }
    }
}

@Composable
fun StatItem(label: String, value: String, valueColor: Color = TextPrimary, valueSize: androidx.compose.ui.unit.TextUnit = 20.sp) {
    Column {
        Text(label, fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, fontSize = valueSize, fontWeight = FontWeight.Medium, color = valueColor)
    }
}
