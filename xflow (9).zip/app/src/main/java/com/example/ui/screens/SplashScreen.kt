package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.R
import com.example.ui.theme.Accent
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController) {
    var animState by remember { mutableStateOf("start") } // start, hold, fade_out
    
    val alphaAnim by animateFloatAsState(
        targetValue = when (animState) {
            "start" -> 0f
            "hold" -> 1f
            "fade_out" -> 0f
            else -> 1f
        },
        animationSpec = tween(durationMillis = 800, easing = LinearOutSlowInEasing)
    )
    
    val scaleAnim by animateFloatAsState(
        targetValue = when (animState) {
            "start" -> 0.8f
            "hold" -> 1f
            "fade_out" -> 1.05f
            else -> 1f
        },
        animationSpec = tween(durationMillis = 800, easing = LinearOutSlowInEasing)
    )

    LaunchedEffect(key1 = true) {
        animState = "hold"
        delay(1200) // Hold for a bit
        animState = "fade_out"
        delay(800) // Wait for fade out
        navController.navigate("home") {
            popUpTo("splash") { inclusive = true }
        }
    }
    
    val bgGradient = Brush.linearGradient(
        colors = listOf(Color(0xFF1A1A1A), Color(0xFF050505))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgGradient),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .alpha(alphaAnim)
                .scale(scaleAnim)
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_x_logo),
                contentDescription = "XFlow Logo",
                tint = Color.Unspecified,
                modifier = Modifier.size(120.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "XFlow",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Focus • Flow • Progress",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Accent,
                letterSpacing = 1.sp
            )
        }
    }
}
