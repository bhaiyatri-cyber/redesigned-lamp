package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.data.Schedule
import com.example.ui.theme.*

import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun HistoryScreen(navController: NavController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()
    
    val allSchedules by db.scheduleDao().getAllSchedules().collectAsState(initial = emptyList())
    val historyItems = allSchedules.filter { it.status !in listOf("Upcoming", "Waiting", "Running", "Paused") }
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf<Set<Int>>(emptySet()) }
    
    var showDeleteAllConfirm by remember { mutableStateOf(false) }
    var showDeleteSelectedConfirm by remember { mutableStateOf(false) }
    var showDeleteSingleConfirm by remember { mutableStateOf<Schedule?>(null) }
    
    val filteredHistory = historyItems.filter { schedule ->
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val dateString = dateFormat.format(Date(schedule.createdAt))
        val matchesSearch = schedule.subject.contains(searchQuery, ignoreCase = true) || dateString.contains(searchQuery, ignoreCase = true)
        
        val matchesFilter = when (selectedFilter) {
            "All" -> true
            "Completed" -> schedule.status == "Completed"
            "Partial" -> schedule.status in listOf("Almost Completed", "Good Progress", "Partial Progress", "Low Progress")
            "Missed" -> schedule.status == "Missed"
            "Online" -> schedule.isOnlineMode
            "Offline" -> !schedule.isOnlineMode
            else -> true
        }
        
        matchesSearch && matchesFilter
    }.sortedByDescending { it.createdAt }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    if (isSelectionMode) {
                        Text("${selectedIds.size} Selected", fontWeight = FontWeight.Bold, color = TextPrimary)
                    } else {
                        Text("History", fontWeight = FontWeight.Bold, color = TextPrimary) 
                    }
                },
                navigationIcon = {
                    if (isSelectionMode) {
                        IconButton(onClick = { 
                            isSelectionMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel", tint = TextPrimary)
                        }
                    } else {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                        }
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        IconButton(onClick = { showDeleteSelectedConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = Accent)
                        }
                    } else if (historyItems.isNotEmpty()) {
                        IconButton(onClick = { showDeleteAllConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete All", tint = Accent)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Background,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search and Filter
            if (!isSelectionMode && historyItems.isNotEmpty()) {
                Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search subject or date...", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary) },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Surface,
                            unfocusedContainerColor = Surface,
                            focusedBorderColor = Accent,
                            unfocusedBorderColor = BorderColorLight
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val filters = listOf("All", "Completed", "Partial", "Missed", "Online", "Offline")
                        items(filters) { filter ->
                            val isSelected = selectedFilter == filter
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSelected) Accent else Surface)
                                    .border(1.dp, if (isSelected) Accent else BorderColorLight, RoundedCornerShape(16.dp))
                                    .clickable { selectedFilter = filter }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    filter, 
                                    color = if (isSelected) Background else TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            if (historyItems.isEmpty()) {
                // Empty State
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 24.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Surface)
                        .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.List, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "No study sessions yet.\nCompleted sessions will appear here.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else if (filteredHistory.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No results found.", color = TextSecondary)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredHistory, key = { it.id }) { schedule ->
                        Box(modifier = Modifier.padding(horizontal = 24.dp)) {
                            HistoryCard(
                                schedule = schedule,
                                isSelectionMode = isSelectionMode,
                                isSelected = selectedIds.contains(schedule.id),
                                onClick = {
                                    if (isSelectionMode) {
                                        selectedIds = if (selectedIds.contains(schedule.id)) {
                                            selectedIds - schedule.id
                                        } else {
                                            selectedIds + schedule.id
                                        }
                                    } else {
                                        navController.navigate("task_details/${schedule.id}")
                                    }
                                },
                                onLongClick = {
                                    if (!isSelectionMode) {
                                        isSelectionMode = true
                                        selectedIds = setOf(schedule.id)
                                    }
                                },
                                onDeleteClick = { showDeleteSingleConfirm = schedule }
                            )
                        }
                    }
                }
            }
        }
    }
    
    // Delete All Confirmation
    if (showDeleteAllConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteAllConfirm = false },
            title = { Text("Delete All History", color = TextPrimary) },
            text = { Text("Are you sure you want to delete all history? This cannot be undone.", color = TextSecondary) },
            containerColor = Surface,
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        historyItems.forEach { db.scheduleDao().deleteSchedule(it) }
                        showDeleteAllConfirm = false
                    }
                }) {
                    Text("Delete All", color = Color(0xFFF44336), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllConfirm = false }) {
                    Text("Cancel", color = Accent)
                }
            }
        )
    }
    
    // Delete Selected Confirmation
    if (showDeleteSelectedConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteSelectedConfirm = false },
            title = { Text("Delete Selected", color = TextPrimary) },
            text = { Text("Are you sure you want to delete the selected history items?", color = TextSecondary) },
            containerColor = Surface,
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val toDelete = historyItems.filter { it.id in selectedIds }
                        toDelete.forEach { db.scheduleDao().deleteSchedule(it) }
                        isSelectionMode = false
                        selectedIds = emptySet()
                        showDeleteSelectedConfirm = false
                    }
                }) {
                    Text("Delete", color = Color(0xFFF44336), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteSelectedConfirm = false }) {
                    Text("Cancel", color = Accent)
                }
            }
        )
    }
    
    // Delete Single Confirmation
    if (showDeleteSingleConfirm != null) {
        AlertDialog(
            onDismissRequest = { showDeleteSingleConfirm = null },
            title = { Text("Delete Entry", color = TextPrimary) },
            text = { Text("Are you sure you want to delete this history entry?", color = TextSecondary) },
            containerColor = Surface,
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        db.scheduleDao().deleteSchedule(showDeleteSingleConfirm!!)
                        showDeleteSingleConfirm = null
                    }
                }) {
                    Text("Delete", color = Color(0xFFF44336), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteSingleConfirm = null }) {
                    Text("Cancel", color = Accent)
                }
            }
        )
    }
}

@androidx.compose.foundation.ExperimentalFoundationApi
@Composable
fun HistoryCard(
    schedule: Schedule, 
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val totalMins = (schedule.totalTimeSeconds / 60).toInt()
    val compMins = (schedule.timeCompletedSeconds / 60).toInt()
    val percent = if (schedule.totalTimeSeconds > 0) {
        (schedule.timeCompletedSeconds.toFloat() / schedule.totalTimeSeconds * 100).toInt()
    } else 0
    
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val dateString = dateFormat.format(Date(schedule.createdAt))

    val resultColor = when (schedule.status) {
        "Completed" -> Color(0xFF4CAF50)
        "Missed" -> Color(0xFFF44336)
        else -> Accent
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(if (isSelected) Accent.copy(alpha = 0.1f) else Surface)
            .border(1.dp, if (isSelected) Accent else BorderColorLight, RoundedCornerShape(24.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(16.dp)
    ) {
        Column {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(schedule.subject.take(1).uppercase(), fontSize = 16.sp, color = TextTertiary)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(schedule.subject, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                    Text(dateString, fontSize = 12.sp, color = TextSecondary)
                }
                
                if (isSelectionMode) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = null,
                        colors = CheckboxDefaults.colors(checkedColor = Accent)
                    )
                } else {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("STUDY TIME", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${compMins}m / ${totalMins}m", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("COMPLETION", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$percent%", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("MODE", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (schedule.isOnlineMode) "Online" else "Offline", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(resultColor.copy(alpha = 0.1f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Result: ${schedule.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = resultColor)
            }
        }
    }
}
