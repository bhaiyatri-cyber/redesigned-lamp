package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "schedules")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val description: String,
    val totalTimeSeconds: Long,
    val timeCompletedSeconds: Long = 0,
    val isOnlineMode: Boolean,
    val targetAppPackage: String? = null,
    val status: String = "Upcoming", // Upcoming, Running, Complete, Partial
    val createdAt: Long = System.currentTimeMillis(),
    val scheduleMode: String = "Duration",
    val startTimeMillis: Long = 0L,
    val endTimeMillis: Long = 0L
)
