with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_accel = """            } else if (event.sensor.type == Sensor.TYPE_LINEAR_ACCELERATION) {
                val dx = Math.abs(event.values[0] - lastAccelX)
                val dy = Math.abs(event.values[1] - lastAccelY)
                val dz = Math.abs(event.values[2] - lastAccelZ)
                lastAccelX = event.values[0]
                lastAccelY = event.values[1]
                lastAccelZ = event.values[2]
                isStable = (dx < 0.5f && dy < 0.5f && dz < 0.5f)
            }"""

new_accel = """            } else if (event.sensor.type == Sensor.TYPE_LINEAR_ACCELERATION) {
                val ax = Math.abs(event.values[0])
                val ay = Math.abs(event.values[1])
                val az = Math.abs(event.values[2])
                isStable = (ax < 1.0f && ay < 1.0f && az < 1.0f)
            }"""

content = content.replace(old_accel, new_accel)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
