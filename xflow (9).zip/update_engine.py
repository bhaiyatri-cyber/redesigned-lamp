with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

import re

old_sensor = """    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_GRAVITY) {
                val z = event.values[2]
                isFaceDown = z < -8.0 
                checkConditionsAndToggleTimer()
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }"""

new_sensor = """    private var lastAccelX = 0f
    private var lastAccelY = 0f
    private var lastAccelZ = 0f
    private var isStable = true

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_GRAVITY) {
                val z = event.values[2]
                isFaceDown = z < -8.0 
            } else if (event.sensor.type == Sensor.TYPE_LINEAR_ACCELERATION) {
                val dx = Math.abs(event.values[0] - lastAccelX)
                val dy = Math.abs(event.values[1] - lastAccelY)
                val dz = Math.abs(event.values[2] - lastAccelZ)
                lastAccelX = event.values[0]
                lastAccelY = event.values[1]
                lastAccelZ = event.values[2]
                isStable = (dx < 0.5f && dy < 0.5f && dz < 0.5f)
            }
            checkConditionsAndToggleTimer()
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }"""

content = content.replace(old_sensor, new_sensor)

old_register = """        sensorManager.registerListener(sensorListener, sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_NORMAL)"""

new_register = """        sensorManager.registerListener(sensorListener, sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(sensorListener, sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_NORMAL)"""

content = content.replace(old_register, new_register)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
