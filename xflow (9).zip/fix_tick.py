with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

# Modify tick()
old_tick_1 = """            val exactPending = allSchedules.filter { 
                it.scheduleMode == "Exact" && 
                it.status in listOf("Upcoming", "Waiting", "Paused", "Running")
            }
            for (schedule in exactPending) {"""

new_tick_1 = """            val pending = allSchedules.filter { 
                it.status in listOf("Upcoming", "Waiting", "Paused", "Running")
            }
            for (schedule in pending) {"""

content = content.replace(old_tick_1, new_tick_1)

old_tick_2 = """                if (now >= schedule.startTimeMillis && now < schedule.endTimeMillis) {
                    startSchedule(schedule, isAutoStart = true)
                    break
                }"""

new_tick_2 = """                if (schedule.scheduleMode == "Exact" && now >= schedule.startTimeMillis && now < schedule.endTimeMillis) {
                    startSchedule(schedule, isAutoStart = true)
                    break
                }"""

content = content.replace(old_tick_2, new_tick_2)

old_tick_3 = """        } else {
            if (currentActive.scheduleMode == "Exact" && now >= currentActive.endTimeMillis) {
                stopSchedule()
            } else if (currentActive.scheduleMode == "Duration" && _timeRemainingSeconds.value <= 0) {
                stopSchedule()
            } else {"""

new_tick_3 = """        } else {
            if (now >= currentActive.endTimeMillis || _timeRemainingSeconds.value <= 0) {
                stopSchedule()
            } else {"""

content = content.replace(old_tick_3, new_tick_3)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)

