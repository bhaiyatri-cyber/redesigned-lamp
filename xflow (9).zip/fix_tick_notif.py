with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_tick_update = """                    if (schedule.status != newStatus) {
                        CoroutineScope(Dispatchers.IO).launch {
                            scheduleDao.updateSchedule(schedule.copy(status = newStatus))
                        }
                    }"""

new_tick_update = """                    if (schedule.status != newStatus) {
                        val updatedSchedule = schedule.copy(status = newStatus)
                        XFlowService.showCompletionNotification(context, updatedSchedule, newStatus, percentage)
                        CoroutineScope(Dispatchers.IO).launch {
                            scheduleDao.updateSchedule(updatedSchedule)
                        }
                    }"""

content = content.replace(old_tick_update, new_tick_update)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
