with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    content = f.read()

import re

# Find:
target = """                        } else {
                            Text("Select Target App", color = TextSecondary)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextPrimary)
                    }
            }
            Spacer(modifier = Modifier.height(32.dp))"""

replacement = """                        } else {
                            Text("Select Target App", color = TextSecondary)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextPrimary)
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))"""

if target in content:
    content = content.replace(target, replacement)
    print("Fixed!")
else:
    print("Target not found.")

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
    f.write(content)
