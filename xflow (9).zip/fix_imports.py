import os

def fix_import(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    if 'Dimensions.padding' in content and 'import com.example.ui.theme.Dimensions' not in content:
        content = content.replace('import androidx.compose.ui.Modifier', 'import androidx.compose.ui.Modifier\nimport com.example.ui.theme.Dimensions')
        with open(file_path, 'w') as f:
            f.write(content)

for root, _, files in os.walk('app/src/main/java/com/example/ui/screens'):
    for file in files:
        if file.endswith('.kt'):
            fix_import(os.path.join(root, file))
