with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    content = f.read()

import re

# We need to find the specific block and ensure it has proper closing braces
target = """                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextPrimary)
                    }
            }
            Spacer(modifier = Modifier.height(32.dp))"""

replacement = """                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextPrimary)
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
        f.write(content)
    print("Fixed braces")
else:
    print("Target not found")
