import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Restore StatCard usage inside Row
# We had replaced .width(160.dp) with .weight(1f) earlier for the two stat cards in HomeScreen
# Let's find StatCard(...) and change it
content = content.replace(
    'StatCard(title = "Study Time", value = formatTimeShort(todayStudyTime), label = "Today", modifier = Modifier.weight(1f))',
    'StatCard(title = "Study Time", value = formatTimeShort(todayStudyTime), label = "Today", modifier = Modifier.width(160.dp))'
)
content = content.replace(
    'StatCard(title = "Sessions", value = todaySessions.toString(), label = "Completed", modifier = Modifier.weight(1f))',
    'StatCard(title = "Sessions", value = todaySessions.toString(), label = "Completed", modifier = Modifier.width(160.dp))'
)
content = content.replace(
    'StatCard(title = "Lifetime", value = formatTimeShort(totalStudyTime), label = "Total", modifier = Modifier.weight(1f))',
    'StatCard(title = "Lifetime", value = formatTimeShort(totalStudyTime), label = "Total", modifier = Modifier.width(160.dp))'
)
content = content.replace(
    'StatCard(title = "Overall Perf", value = perf, label = "Efficiency", modifier = Modifier.weight(1f))',
    'StatCard(title = "Overall Perf", value = perf, label = "Efficiency", modifier = Modifier.width(160.dp))'
)

# Restore StatCard signature and body
old_stat_card = """fun StatCard(title: String, value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 120.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(SurfaceVariant, SurfaceEnd)))
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextTertiary, letterSpacing = 1.5.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 30.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text(label, fontSize = 12.sp, color = Accent, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}"""

new_stat_card = """fun StatCard(title: String, value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(128.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(SurfaceVariant, SurfaceEnd)))
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextTertiary, letterSpacing = 1.5.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 30.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text(label, fontSize = 12.sp, color = Accent, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}"""

content = content.replace(old_stat_card, new_stat_card)

# Restore horizontal scrolls
# Looking at rows after Dashboard (StatCards)
# "                    Row("
content = content.replace(
"""                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {""",
"""                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {"""
)

content = content.replace(
"""                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {""",
"""                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {"""
)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)

