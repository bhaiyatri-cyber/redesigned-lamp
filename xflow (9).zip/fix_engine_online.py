with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

import re

# Fix startAppUsagePolling
old_polling = """    private fun startAppUsagePolling() {
        usagePollingJob = CoroutineScope(Dispatchers.Default).launch {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            while (true) {
                val targetApp = _activeSchedule.value?.targetAppPackage
                if (targetApp != null) {
                    val time = System.currentTimeMillis()
                    val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 10000, time)
                    isTargetAppForeground = stats?.any { 
                        it.packageName == targetApp && it.lastTimeUsed > time - 5000 
                    } == true
                    checkConditionsAndToggleTimer()
                }
                delay(2000)
            }
        }
    }"""

new_polling = """    private var lastCheckedTime: Long = 0
    private var lastForegroundApp: String? = null

    private fun startAppUsagePolling() {
        usagePollingJob = CoroutineScope(Dispatchers.Default).launch {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            lastCheckedTime = System.currentTimeMillis() - 60000
            while (kotlinx.coroutines.isActive) {
                val targetApp = _activeSchedule.value?.targetAppPackage
                if (targetApp != null) {
                    val time = System.currentTimeMillis()
                    val events = usageStatsManager.queryEvents(lastCheckedTime, time)
                    val event = android.app.usage.UsageEvents.Event()
                    while (events.hasNextEvent()) {
                        events.getNextEvent(event)
                        if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                            val pkg = event.packageName
                            if (pkg != "com.android.systemui" && 
                                !pkg.contains("launcher", ignoreCase = true) && 
                                !pkg.contains("inputmethod", ignoreCase = true)) {
                                lastForegroundApp = pkg
                            }
                        }
                    }
                    lastCheckedTime = time
                    isTargetAppForeground = (lastForegroundApp == targetApp)
                    checkConditionsAndToggleTimer()
                }
                delay(2000)
            }
        }
    }"""

content = content.replace(old_polling, new_polling)

# Fix checkConditionsAndToggleTimer stability check for Online mode
old_check = """        } else if (!shouldRun && _isTimerRunning.value) {
            if (!schedule.isOnlineMode) {
                if (graceJob?.isActive != true) {
                    graceJob = CoroutineScope(Dispatchers.Default).launch {
                        delay(10000)
                        pauseTimer()
                    }
                }
            } else {
                pauseTimer()
            }
        }"""

new_check = """        } else if (!shouldRun && _isTimerRunning.value) {
            if (!schedule.isOnlineMode) {
                if (graceJob?.isActive != true) {
                    graceJob = CoroutineScope(Dispatchers.Default).launch {
                        delay(10000)
                        pauseTimer()
                    }
                }
            } else {
                if (graceJob?.isActive != true) {
                    graceJob = CoroutineScope(Dispatchers.Default).launch {
                        delay(4000)
                        pauseTimer()
                    }
                }
            }
        }"""

content = content.replace(old_check, new_check)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
print("Updated XFlowEngine!")
