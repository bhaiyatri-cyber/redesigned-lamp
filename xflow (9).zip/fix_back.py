with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

import re

old_back = """    val s = schedule!!
    val isActive = activeSchedule?.id == s.id"""

new_back = """    val s = schedule!!
    val isActive = activeSchedule?.id == s.id
    
    androidx.activity.compose.BackHandler(enabled = isActive && !s.isOnlineMode) {
        // Session lock: do nothing when back is pressed during an active offline session
    }"""

content = content.replace(old_back, new_back)

old_nav_back = """        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }"""

new_nav_back = """        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!isActive || s.isOnlineMode) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
            } else {
                IconButton(onClick = { /* Session locked */ }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextSecondary)
                }
            }"""

content = content.replace(old_nav_back, new_nav_back)

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
