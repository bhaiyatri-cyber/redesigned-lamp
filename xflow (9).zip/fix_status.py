with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_status_1 = """                    val newStatus = when {
                        percentage >= 100 -> "Completed"
                        percentage >= 75 -> "Almost Completed"
                        percentage >= 50 -> "Good Progress"
                        percentage >= 25 -> "Partial Progress"
                        percentage > 0 -> "Low Progress"
                        else -> "Missed"
                    }"""

new_status_1 = """                    val newStatus = when {
                        percentage >= 100 -> "Completed"
                        percentage > 0 -> "Partial Progress"
                        else -> "Missed"
                    }"""

content = content.replace(old_status_1, new_status_1)

old_status_2 = """        val newStatus = when {
            percentage >= 100 -> "Completed"
            percentage >= 75 -> "Almost Completed"
            percentage >= 50 -> "Good Progress"
            percentage >= 25 -> "Partial Progress"
            percentage > 0 -> "Low Progress"
            else -> "Missed"
        }"""

new_status_2 = """        val newStatus = when {
            percentage >= 100 -> "Completed"
            percentage > 0 -> "Partial Progress"
            else -> "Missed"
        }"""

content = content.replace(old_status_2, new_status_2)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)

