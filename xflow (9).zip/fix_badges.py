with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Fix ONLINE/OFFLINE MODE
content = content.replace(
    'Text(if (schedule.isOnlineMode) "ONLINE MODE" else "OFFLINE MODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)',
    'AutoSizeText(if (schedule.isOnlineMode) "ONLINE MODE" else "OFFLINE MODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp, maxLines = 1)'
)

# Fix STATUS
content = content.replace(
    'Text(schedule.status.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Accent)',
    'AutoSizeText(schedule.status.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Accent, maxLines = 1)'
)

# Fix ACTIVE engine badge
content = content.replace(
    'Text("CENTRAL ENGINE ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)',
    'AutoSizeText("CENTRAL ENGINE ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp, maxLines = 1)'
)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
