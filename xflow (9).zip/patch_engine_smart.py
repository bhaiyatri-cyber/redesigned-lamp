with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

import re

# Update tick() logic
tick_pattern = re.compile(r"(\} else \{)\s+if \(currentActive\.scheduleMode == \"Exact\"\) \{\s+if \(now >= currentActive\.endTimeMillis\) \{\s+stopSchedule\(\)\s+\} else if \(now >= currentActive\.startTimeMillis && currentActive\.status == \"Upcoming\"\) \{\s+val updated = currentActive\.copy\(status = \"Waiting\"\)\s+_activeSchedule\.value = updated\s+CoroutineScope\(Dispatchers\.IO\)\.launch \{ scheduleDao\.updateSchedule\(updated\) \}\s+\}\s+\} else if \(currentActive\.scheduleMode == \"Duration\"\) \{\s+if \(_timeRemainingSeconds\.value <= 0\) \{\s+stopSchedule\(\)\s+\}\s+\}", re.MULTILINE)

new_tick = """} else {
            if (now >= currentActive.endTimeMillis) {
                stopSchedule()
            } else {
                if (currentActive.scheduleMode == "Exact" && now >= currentActive.startTimeMillis && currentActive.status == "Upcoming") {
                    val updated = currentActive.copy(status = "Waiting")
                    _activeSchedule.value = updated
                    CoroutineScope(Dispatchers.IO).launch { scheduleDao.updateSchedule(updated) }
                }
                if (_timeRemainingSeconds.value <= 0) {
                    stopSchedule()
                }
            }"""

content = tick_pattern.sub(new_tick, content)

# Update checkConditionsAndToggleTimer() logic
cond_pattern = re.compile(r"if \(schedule\.scheduleMode == \"Exact\"\) \{\s+if \(now < schedule\.startTimeMillis \|\| now >= schedule\.endTimeMillis\) \{\s+timeValid = false\s+\}\s+\}")

new_cond = """if (now < schedule.startTimeMillis || now >= schedule.endTimeMillis) {
            timeValid = false
        }"""

content = cond_pattern.sub(new_cond, content)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
print("Engine Patched!")
