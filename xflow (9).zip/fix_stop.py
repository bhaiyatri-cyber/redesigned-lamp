with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_percentage_1 = """                    val percentage = if (schedule.totalTimeSeconds > 0) {
                        (timeCompleted.toFloat() / schedule.totalTimeSeconds * 100).toInt()
                    } else 0"""

new_percentage_1 = """                    val percentage = if (schedule.totalTimeSeconds > 0) {
                        (timeCompleted.toFloat() / schedule.totalTimeSeconds * 100).toInt().coerceIn(0, 100)
                    } else 0"""

content = content.replace(old_percentage_1, new_percentage_1)

old_percentage_2 = """        val percentage = if (current.totalTimeSeconds > 0) {
            (timeCompleted.toFloat() / current.totalTimeSeconds * 100).toInt()
        } else {
            0
        }"""

new_percentage_2 = """        val percentage = if (current.totalTimeSeconds > 0) {
            (timeCompleted.toFloat() / current.totalTimeSeconds * 100).toInt().coerceIn(0, 100)
        } else {
            0
        }"""

content = content.replace(old_percentage_2, new_percentage_2)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
