with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "Column(modifier = Modifier.width(160.dp)) {" in line and ("Text(\"${missingPermission} Required\"" in lines[i+1] or "Text(schedule.subject" in lines[i+1]):
        lines[i] = line.replace("Modifier.width(160.dp)", "Modifier.weight(1f)")
    if "modifier = Modifier.width(160.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x0DFFFFFF))" in line:
        lines[i] = line.replace("Modifier.width(160.dp)", "Modifier.weight(1f)")

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.writelines(lines)
