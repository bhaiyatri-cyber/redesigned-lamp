with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for i, line in enumerate(lines):
    new_lines.append(line)
    if "Icon(Icons.Default.ArrowDropDown, contentDescription = \"Select\", tint = TextPrimary)" in line:
        new_lines.append(lines[i+1])
        new_lines.append("                }\n")
        
        # We need to skip lines[i+1] since we added it manually
        lines[i+1] = "" # Blank it out so it doesn't get added twice

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
    f.writelines(new_lines)
