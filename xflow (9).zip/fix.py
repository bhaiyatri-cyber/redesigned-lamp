with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

start_marker = "    if (isActive) {"
end_marker = "    } else {\n        Box("

import re

new_active = """    if (isActive) {
        Column(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Current Session", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Accent))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("CENTRAL ENGINE ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Surface)
                    .border(1.dp, BorderColor, RoundedCornerShape(24.dp))
                    .clickable { onClick() }
                    .padding(24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(schedule.subject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(schedule.description, fontSize = 14.sp, color = TextSecondary)
                        }
                        Box(
                            modifier = Modifier
                                .background(Accent.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                                .border(1.dp, Accent.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(if (schedule.isOnlineMode) "ONLINE MODE" else "OFFLINE MODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x0DFFFFFF))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(percent / 100f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Accent)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("$percent%", fontSize = 14.sp, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    val sdf = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
                    val st = sdf.format(java.util.Date(schedule.startTimeMillis))
                    val et = sdf.format(java.util.Date(schedule.endTimeMillis))
                    Row(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Start: $st", fontSize = 12.sp, color = TextSecondary)
                        Text("End: $et", fontSize = 12.sp, color = TextSecondary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Column {
                            Text("STATUS", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(schedule.status.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Accent)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("LIVE TIMER", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(formatTimeFull(currentCompletedSeconds), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    val nowMillis = System.currentTimeMillis()
                    val remSecondsEnd = if (nowMillis < schedule.endTimeMillis) (schedule.endTimeMillis - nowMillis) / 1000 else 0
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Study Time: ${currentCompletedSeconds / 60}m", fontSize = 12.sp, color = TextSecondary)
                        Text("Time Until End: ${formatTimeFull(remSecondsEnd)}", fontSize = 12.sp, color = TextSecondary)
                    }
                }
            }
        }
"""

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + new_active + content[end_idx:]
    with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
        f.write(new_content)
    print("Success")
else:
    print("Markers not found")
