with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    content = f.read()

# Replace all occurrences of 
# "                    }\n                }"
# back to
# "                    }"
# But wait, there might be legitimate "}\n                }"
# But I added them using sed.
content = content.replace("                    }\n                }", "                    }")

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
    f.write(content)
print("Reversed sed")
