with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_notif = """        XFlowService.showCompletionNotification(context, current, newStatus, percentage)
        
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(
                current.copy(
                    status = newStatus,
                    timeCompletedSeconds = timeCompleted
                )
            )
        }"""

new_notif = """        val updatedSchedule = current.copy(
            status = newStatus,
            timeCompletedSeconds = timeCompleted
        )
        
        XFlowService.showCompletionNotification(context, updatedSchedule, newStatus, percentage)
        
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(updatedSchedule)
        }"""

content = content.replace(old_notif, new_notif)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)

