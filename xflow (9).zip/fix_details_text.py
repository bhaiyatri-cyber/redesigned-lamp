with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

if 'import com.example.ui.components.AutoSizeText' not in content:
    content = content.replace('import com.example.ui.theme.BorderColorLight', 'import com.example.ui.theme.BorderColorLight\nimport com.example.ui.components.AutoSizeText')

old_detail_row = """@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 14.sp)
        Text(value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}"""

new_detail_row = """@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f, fill = false), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        Spacer(modifier = Modifier.width(16.dp))
        AutoSizeText(value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(2f, fill = false), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}"""

content = content.replace(old_detail_row, new_detail_row)

old_time_str = 'Text(timeStr, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)'
new_time_str = 'AutoSizeText(timeStr, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent, maxLines = 1)'
content = content.replace(old_time_str, new_time_str)

old_title = 'Text(s.subject, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)'
new_title = 'AutoSizeText(s.subject, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 2)'
content = content.replace(old_title, new_title)

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
