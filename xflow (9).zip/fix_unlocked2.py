with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_cond = """            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            val isUnlocked = !keyguardManager.isKeyguardLocked
            
            // If phone is locked, we only care that it's face down and stable.
            // If phone is unlocked (user is looking at it), it MUST be face down and stable to run.
            // Wait, if they just open the app to check, it's unlocked and face up, so this returns false.
            // The grace period will keep it running.
            isFaceDown && isStable && timeValid"""

new_cond = """            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            val isUnlocked = !keyguardManager.isKeyguardLocked
            
            // Offline condition: face-down, stable, and NOT unlocked (unless they are doing a brief check within the grace period)
            // The requirement says: Pause only when the real offline condition fails: phone lifted, phone moved, phone unlocked, phone no longer face-down and stable
            isFaceDown && isStable && !isUnlocked && timeValid"""

content = content.replace(old_cond, new_cond)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
