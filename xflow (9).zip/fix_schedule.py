with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    content = f.read()

# Remove exact fixed height(56.dp) for TextField and Button
content = content.replace('.height(56.dp)', '.defaultMinSize(minHeight = 56.dp)')

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
    f.write(content)
