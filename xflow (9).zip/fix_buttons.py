with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

old_buttons = """            "Running", "Paused" -> {
                if (s.status == "Running") {
                    if (s.isOnlineMode) {
                        Button(
                            onClick = { /* Engine handles pause based on sensor/app state */ },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Pause", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    } else {
                        Button(
                            onClick = { XFlowEngine.stopSchedule() },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Done", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    }
                } else {
                    Button(
                        onClick = { /* Engine handles resume */ },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Resume", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                if (s.isOnlineMode || s.status != "Running") {
                    OutlinedButton(
                        onClick = { XFlowEngine.stopSchedule() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Stop", color = Color.Red)
                    }
                }"""

new_buttons = """            "Running", "Paused" -> {
                if (s.isOnlineMode) {
                    if (s.status == "Running") {
                        Button(
                            onClick = { /* Engine handles pause based on sensor/app state */ },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Pause (Auto)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    } else {
                        Button(
                            onClick = { /* Engine handles resume */ },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Resume (Auto)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { XFlowEngine.stopSchedule() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Stop", color = Color.Red)
                    }
                } else {
                    // Offline Mode
                    Button(
                        onClick = { XFlowEngine.stopSchedule() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Done", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { 
                            scope.launch(Dispatchers.IO) {
                                XFlowEngine.stopSchedule()
                                val skipped = s.copy(status = "Skipped", timeCompletedSeconds = currentCompletedSeconds)
                                db.scheduleDao().updateSchedule(skipped)
                                schedule = skipped
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Cancel Session", color = TextPrimary)
                    }
                }"""

content = content.replace(old_buttons, new_buttons)
with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
