with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

import re

# We need to restore the part from line 192 down.
# Let's completely rewrite the UI from `DetailRow("Completion", "$percent%")` downwards.

new_ui = """                DetailRow("Completion", "$percent%")
                
                val finalResult = when {
                    isActive -> "Running"
                    s.status in listOf("Upcoming", "Waiting", "Paused") -> "N/A"
                    else -> s.status
                }
                DetailRow("Result", finalResult)
                
                if (!isActive && s.status !in listOf("Upcoming", "Waiting", "Paused")) {
                    val message = when (s.status) {
                        "Completed" -> "Perfect session!"
                        "Almost Completed" -> "So close!"
                        "Good Progress" -> "Solid effort."
                        "Partial Progress" -> "A fair start."
                        "Low Progress" -> "Needs more focus."
                        else -> "Session missed."
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceVariant).padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(message, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Actions
        when (s.status) {
            "Upcoming", "Waiting" -> {
                Button(
                    onClick = { XFlowEngine.startSchedule(s) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Start", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showEditDialog = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Edit", color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Delete", color = Color.Red)
                }
            }
            "Running", "Paused" -> {
                if (s.isOnlineMode) {
                    if (s.status == "Running") {
                        Button(
                            onClick = { /* Engine handles pause based on sensor/app state */ },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Pause (Auto)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    } else {
                        Button(
                            onClick = { /* Engine handles resume */ },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Resume (Auto)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { XFlowEngine.stopSchedule() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Stop", color = Color.Red)
                    }
                } else {
                    Button(
                        onClick = { XFlowEngine.stopSchedule() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Done", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { 
                            scope.launch(Dispatchers.IO) {
                                XFlowEngine.stopSchedule()
                                val skipped = s.copy(status = "Skipped", timeCompletedSeconds = currentCompletedSeconds)
                                db.scheduleDao().updateSchedule(skipped)
                                schedule = skipped
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Cancel Session", color = TextPrimary)
                    }
                }
            }
            "Completed", "Partial Progress", "Missed", "Skipped" -> {"""

pattern = re.compile(r'DetailRow\("Completion", "\$percent%"\).*?"Completed", "Partial Progress", "Missed", "Skipped" -> \{', re.DOTALL)

content = pattern.sub(new_ui, content)

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
