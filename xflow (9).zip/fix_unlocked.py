with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'r') as f:
    content = f.read()

old_cond = """        val shouldRun = if (schedule.isOnlineMode) {
            isTargetAppForeground && timeValid
        } else {
            isFaceDown && timeValid
        }"""

new_cond = """        val shouldRun = if (schedule.isOnlineMode) {
            isTargetAppForeground && timeValid
        } else {
            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            val isUnlocked = !keyguardManager.isKeyguardLocked
            
            // If phone is locked, we only care that it's face down and stable.
            // If phone is unlocked (user is looking at it), it MUST be face down and stable to run.
            // Wait, if they just open the app to check, it's unlocked and face up, so this returns false.
            // The grace period will keep it running.
            isFaceDown && isStable && timeValid
        }"""

content = content.replace(old_cond, new_cond)

with open('app/src/main/java/com/example/engine/XFlowEngine.kt', 'w') as f:
    f.write(content)
