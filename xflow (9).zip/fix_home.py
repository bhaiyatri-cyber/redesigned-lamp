with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'modifier = Modifier.width(160.dp)',
    'modifier = Modifier.weight(1f)'
)

content = content.replace(
    'import androidx.compose.foundation.layout.*',
    'import androidx.compose.foundation.layout.*\nimport com.example.ui.components.AutoSizeText'
)

# Fix StatCard
old_stat_card = """fun StatCard(title: String, value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(128.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(SurfaceVariant, SurfaceEnd)))
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextTertiary, letterSpacing = 1.5.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 30.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text(label, fontSize = 12.sp, color = Accent, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}"""

new_stat_card = """fun StatCard(title: String, value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 120.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(SurfaceVariant, SurfaceEnd)))
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            AutoSizeText(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextTertiary, letterSpacing = 1.5.sp, maxLines = 1)
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                AutoSizeText(value, fontSize = 30.sp, fontWeight = FontWeight.Light, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                Spacer(modifier = Modifier.width(4.dp))
                Text(label, fontSize = 12.sp, color = Accent, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}"""

content = content.replace(old_stat_card, new_stat_card)

# Let's fix the horizontalScroll to just a simple weight based Row.
old_scroll_row_1 = """                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {"""

new_scroll_row_1 = """                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {"""

content = content.replace(old_scroll_row_1, new_scroll_row_1)

old_scroll_row_2 = """                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {"""

new_scroll_row_2 = """                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {"""

content = content.replace(old_scroll_row_2, new_scroll_row_2)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
