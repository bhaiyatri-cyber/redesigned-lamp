with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# For the list items
old_subject = 'Text(schedule.subject, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)'
new_subject = 'Text(schedule.subject, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_subject, new_subject)

old_studied = 'Text("Studied: ${compMins}m | Remaining: ${remainingMins}m", fontSize = 12.sp, color = TextSecondary)'
new_studied = 'Text("Studied: ${compMins}m | Remaining: ${remainingMins}m", fontSize = 12.sp, color = TextSecondary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_studied, new_studied)

old_comp = 'Text("Completion: $percent% | Result: ${schedule.status}", fontSize = 12.sp, color = Accent)'
new_comp = 'Text("Completion: $percent% | Result: ${schedule.status}", fontSize = 12.sp, color = Accent, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_comp, new_comp)

old_status1 = 'Text("${schedule.status} • $compMins min done, $remainingMins min left ($percent%)", fontSize = 12.sp, color = TextSecondary)'
new_status1 = 'Text("${schedule.status} • $compMins min done, $remainingMins min left ($percent%)", fontSize = 12.sp, color = TextSecondary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_status1, new_status1)

old_status2 = 'Text("${schedule.status} • $compMins / $totalMins mins", fontSize = 12.sp, color = TextSecondary)'
new_status2 = 'Text("${schedule.status} • $compMins / $totalMins mins", fontSize = 12.sp, color = TextSecondary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)'
content = content.replace(old_status2, new_status2)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
