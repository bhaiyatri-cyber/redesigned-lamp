import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# I want to add hasForeground
content = content.replace(
    'var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }',
    'var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }\n    var hasForeground by remember { mutableStateOf(XFlowEngine.checkForegroundService(context)) }'
)

content = content.replace(
    'hasNotification = XFlowEngine.checkNotification(context)',
    'hasNotification = XFlowEngine.checkNotification(context)\n                hasForeground = XFlowEngine.checkForegroundService(context)'
)

content = content.replace(
    'val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification) {',
    'val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification, hasForeground) {'
)

content = content.replace(
    'else if (!hasNotification) "Notification"',
    'else if (!hasForeground) "Foreground Service"\n            else if (!hasNotification) "Notification"'
)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)

