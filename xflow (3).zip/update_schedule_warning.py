import re

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'val hasBattery = XFlowEngine.checkBatteryOpt(context)',
    'val hasBattery = XFlowEngine.checkBatteryOpt(context)\n                    val hasForeground = XFlowEngine.checkForegroundService(context)'
)

content = content.replace(
    'if ((isOnlineMode && !hasUsage) || !hasNotif || !hasBattery)',
    'if ((isOnlineMode && !hasUsage) || !hasNotif || !hasBattery || !hasForeground)'
)

with open('app/src/main/java/com/example/ui/screens/ScheduleScreen.kt', 'w') as f:
    f.write(content)
