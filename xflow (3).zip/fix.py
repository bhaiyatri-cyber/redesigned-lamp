import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# The first Column(modifier = Modifier.weight(1f)) is at line 150.
# Let's replace the first one with the original missingPermission code.

original_missing_permission = """                        Column(modifier = Modifier.weight(1f)) {
                            Text("${missingPermission} Required", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Schedule paused until granted.", color = TextSecondary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = { navController.navigate("settings") },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Grant Permission", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
"""

# and the second one should be the schedule one.

# Let's just find the `if (missingPermission != null) {` block and replace it correctly.

def replace_block(text, start_str, end_str, replacement):
    start_idx = text.find(start_str)
    if start_idx == -1: return text
    end_idx = text.find(end_str, start_idx)
    if end_idx == -1: return text
    return text[:start_idx] + replacement + text[end_idx + len(end_str):]

# Let's see the current text of missing permission block
# Wait, my previous replacement might have messed up the end bounds, let me check lines 140 to 170.

