import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

card_code = """
            if (missingPermission != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${missingPermission} Required", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Schedule paused until granted.", color = TextSecondary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = { navController.navigate("settings") },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Grant Permission", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
"""

for i, line in enumerate(lines):
    if "if (schedules.isEmpty()) {" in line:
        # Before this line, insert the card
        # Wait, make sure we only insert it once
        # Check if "if (missingPermission != null)" is already there
        if "if (missingPermission != null)" not in "".join(lines[i-30:i]):
            lines.insert(i, card_code)
        break

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.writelines(lines)

