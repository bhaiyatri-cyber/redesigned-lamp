import re

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

replacement = """                                DetailRow("Status", s.status)
                DetailRow("Study Mode", if (s.isOnlineMode) "Online" else "Offline")
                if (s.isOnlineMode) {
                    DetailRow("Target App", s.targetAppPackage ?: "None")
                }
                
                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = Color(0x20FFFFFF))
                
                DetailRow("Studied", "${compMins}m")
                DetailRow("Remaining", "${remainingSecs / 60}m")
                DetailRow("Completion", "$percent%")
                
                val finalResult = when {
                    isActive -> "Running"
                    s.status in listOf("Upcoming", "Waiting", "Paused") -> "N/A"
                    else -> s.status
                }
                DetailRow("Result", finalResult)
                
                if (!isActive && s.status !in listOf("Upcoming", "Waiting", "Paused")) {
                    val message = when (s.status) {
                        "Completed" -> "Perfect session!"
                        "Almost Completed" -> "So close!"
                        "Good Progress" -> "Solid effort."
                        "Partial Progress" -> "A fair start."
                        "Low Progress" -> "Needs more focus."
                        else -> "Session missed."
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(SurfaceVariant).padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(message, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
"""

content = re.sub(r'                                DetailRow\("Status", s\.status\).*?DetailRow\("Final Result", [^\n]+\)', replacement, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
