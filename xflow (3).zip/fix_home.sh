sed -i '/val activeSchedule/i \
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current\
    var hasUsageAccess by remember { mutableStateOf(XFlowEngine.checkUsageAccess(context)) }\
    var isIgnoringBattery by remember { mutableStateOf(XFlowEngine.checkBatteryOpt(context)) }\
    var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }\
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {\
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->\
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {\
                hasUsageAccess = XFlowEngine.checkUsageAccess(context)\
                isIgnoringBattery = XFlowEngine.checkBatteryOpt(context)\
                hasNotification = XFlowEngine.checkNotification(context)\
            }\
        }\
        lifecycleOwner.lifecycle.addObserver(observer)\
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }\
    }\
\
    val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification) {\
        if (activeSchedule != null) {\
            if (activeSchedule?.isOnlineMode == true && !hasUsageAccess) "Usage Access"\
            else if (!isIgnoringBattery) "Battery Optimization"\
            else if (!hasNotification) "Notification"\
            else null\
        } else null\
    }\
' app/src/main/java/com/example/ui/screens/HomeScreen.kt
