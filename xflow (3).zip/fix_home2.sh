sed -i '/if (schedules.isEmpty()) {/i \
            if (missingPermission != null) {\
                Card(\
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 16.dp),\
                    colors = CardDefaults.cardColors(containerColor = SurfaceVariant),\
                    shape = RoundedCornerShape(16.dp)\
                ) {\
                    Row(\
                        modifier = Modifier.fillMaxWidth().padding(16.dp),\
                        horizontalArrangement = Arrangement.SpaceBetween,\
                        verticalAlignment = Alignment.CenterVertically\
                    ) {\
                        Column(modifier = Modifier.weight(1f)) {\
                            Text("${missingPermission} Required", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)\
                            Text("Schedule paused until granted.", color = TextSecondary, fontSize = 12.sp)\
                        }\
                        Spacer(modifier = Modifier.width(16.dp))\
                        Button(\
                            onClick = { navController.navigate("settings") },\
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background),\
                            shape = RoundedCornerShape(12.dp)\
                        ) {\
                            Text("Grant Permission", fontWeight = FontWeight.Bold, fontSize = 12.sp)\
                        }\
                    }\
                }\
            }\
' app/src/main/java/com/example/ui/screens/HomeScreen.kt
