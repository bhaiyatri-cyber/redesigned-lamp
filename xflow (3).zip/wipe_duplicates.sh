awk '
/val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current/ {
    count_lifecycle++
    if (count_lifecycle > 1) { skip = 1 }
}
/val missingPermission = remember\(activeSchedule, hasUsageAccess/ {
    count_missing++
    if (count_missing > 1) { skip = 1 }
}
{
    if (skip == 1) {
        if (/^ *\}$/) {
            closing_braces++
            if (closing_braces == 2 && count_missing > 1) {
                # We skipped the second missingPermission block
                skip = 0
            } else if (closing_braces == 1 && count_lifecycle > 1) {
                # We skipped the second lifecycle block
                skip = 0
            }
        }
        next
    }
    print
}
' app/src/main/java/com/example/ui/screens/HomeScreen.kt > temp.kt && mv temp.kt app/src/main/java/com/example/ui/screens/HomeScreen.kt
