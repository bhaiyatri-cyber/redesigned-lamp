import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# I will find the `@Composable\nfun HomeScreen(navController: NavController) {`
# And then replace its content up to `Scaffold(`

start_marker = "fun HomeScreen(navController: NavController) {"
end_marker = "    Scaffold("

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx != -1 and end_idx != -1:
    new_middle = """
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    val schedules by db.scheduleDao().getAllSchedules().collectAsState(initial = emptyList())
    
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasUsageAccess by remember { mutableStateOf(XFlowEngine.checkUsageAccess(context)) }
    var isIgnoringBattery by remember { mutableStateOf(XFlowEngine.checkBatteryOpt(context)) }
    var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }
    
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = XFlowEngine.checkUsageAccess(context)
                isIgnoringBattery = XFlowEngine.checkBatteryOpt(context)
                hasNotification = XFlowEngine.checkNotification(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    
    val activeSchedule by XFlowEngine.activeSchedule.collectAsState()
    val isTimerRunning by XFlowEngine.isTimerRunning.collectAsState()
    val timeRemaining by XFlowEngine.timeRemainingSeconds.collectAsState()
    
    val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification) {
        if (activeSchedule != null) {
            if (activeSchedule?.isOnlineMode == true && !hasUsageAccess) "Usage Access"
            else if (!isIgnoringBattery) "Battery Optimization"
            else if (!hasNotification) "Notification"
            else null
        } else null
    }

    val todayStart = remember {
        java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    
    val todayCompletedSeconds = schedules.filter { it.createdAt >= todayStart }.sumOf { it.timeCompletedSeconds }
    val lifetimeCompletedSeconds = schedules.sumOf { it.timeCompletedSeconds }
    
"""
    new_content = content[:start_idx + len(start_marker)] + "\n" + new_middle + content[end_idx:]
    with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
        f.write(new_content)
        
