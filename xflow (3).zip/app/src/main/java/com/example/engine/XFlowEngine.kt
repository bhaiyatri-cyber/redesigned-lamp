package com.example.engine

import android.app.usage.UsageStatsManager
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import com.example.data.Schedule
import com.example.data.ScheduleDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlin.math.abs

object XFlowEngine {
    private val _activeSchedule = MutableStateFlow<Schedule?>(null)
    val activeSchedule: StateFlow<Schedule?> = _activeSchedule.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _timeRemainingSeconds = MutableStateFlow(0L)
    val timeRemainingSeconds: StateFlow<Long> = _timeRemainingSeconds.asStateFlow()

    private var timerJob: Job? = null
    private lateinit var scheduleDao: ScheduleDao
    private lateinit var context: Context
    private lateinit var sensorManager: SensorManager
    private var gravitySensor: Sensor? = null

    private var isFaceDown = false
    private var isTargetAppForeground = false

        suspend fun restoreBackup(schedules: List<Schedule>) {
        stopSchedule()
        scheduleDao.clearAll()
        for (schedule in schedules) {
            scheduleDao.insertSchedule(schedule)
        }
    }

    suspend fun getAllSchedulesOnce(): List<Schedule> {
        return scheduleDao.getAllSchedules().firstOrNull() ?: emptyList()
    }

    fun init(appContext: Context, dao: ScheduleDao) {
        context = appContext
        scheduleDao = dao
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_GRAVITY) {
                val z = event.values[2]
                // z is close to -9.8 when face down on a table
                isFaceDown = z < -8.0 
                checkConditionsAndToggleTimer()
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    fun startSchedule(schedule: Schedule) {
        val timeCompleted = schedule.timeCompletedSeconds
        _timeRemainingSeconds.value = schedule.totalTimeSeconds - timeCompleted
        
        val waitingSchedule = schedule.copy(status = "Waiting")
        _activeSchedule.value = waitingSchedule
        
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(waitingSchedule)
        }

        XFlowService.startService(context)

        if (schedule.isOnlineMode) {
            startAppUsagePolling()
        } else {
            sensorManager.registerListener(sensorListener, gravitySensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        
        checkConditionsAndToggleTimer()
    }

    fun stopSchedule() {
        val current = _activeSchedule.value ?: return
        
        timerJob?.cancel()
        timerJob = null
        _isTimerRunning.value = false
        
        sensorManager.unregisterListener(sensorListener)
        usagePollingJob?.cancel()

        XFlowService.stopService(context)

        val timeCompleted = current.totalTimeSeconds - _timeRemainingSeconds.value
        val percentage = if (current.totalTimeSeconds > 0) {
            (timeCompleted.toFloat() / current.totalTimeSeconds * 100).toInt()
        } else {
            0
        }
        val newStatus = when {
            percentage >= 100 -> "Completed"
            percentage >= 75 -> "Almost Completed"
            percentage >= 50 -> "Good Progress"
            percentage >= 25 -> "Partial Progress"
            percentage > 0 -> "Low Progress"
            else -> "Missed"
        }
        
        XFlowService.showCompletionNotification(context, current, newStatus, percentage)
        
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(
                current.copy(
                    status = newStatus,
                    timeCompletedSeconds = timeCompleted
                )
            )
        }
        _activeSchedule.value = null
    }

    private fun checkConditionsAndToggleTimer() {
        val schedule = _activeSchedule.value ?: return
        val shouldRun = if (schedule.isOnlineMode) {
            isTargetAppForeground
        } else {
            isFaceDown
        }

        if (shouldRun && !_isTimerRunning.value) {
            resumeTimer()
        } else if (!shouldRun && _isTimerRunning.value) {
            pauseTimer()
        }
    }

    private fun resumeTimer() {
        if (timerJob?.isActive == true) return
        _isTimerRunning.value = true
        timerJob = CoroutineScope(Dispatchers.Default).launch {
            val current = _activeSchedule.value
            if (current != null) {
                val updated = current.copy(status = "Running")
                _activeSchedule.value = updated
                scheduleDao.updateSchedule(updated)
            }
            while (_timeRemainingSeconds.value > 0 && _isTimerRunning.value) {
                delay(1000)
                _timeRemainingSeconds.value -= 1
                if (_timeRemainingSeconds.value <= 0) {
                    stopSchedule()
                }
            }
        }
    }

    private fun pauseTimer() {
        if (!_isTimerRunning.value) return
        _isTimerRunning.value = false
        timerJob?.cancel()
        timerJob = null
        
        // Update DB with partial progress and Paused status
        val current = _activeSchedule.value ?: return
        val timeCompleted = current.totalTimeSeconds - _timeRemainingSeconds.value
        val updated = current.copy(status = "Paused", timeCompletedSeconds = timeCompleted)
        _activeSchedule.value = updated
        CoroutineScope(Dispatchers.IO).launch {
            scheduleDao.updateSchedule(updated)
        }
    }

    private var usagePollingJob: Job? = null
    fun checkUsageAccess(ctx: Context = context): Boolean { val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager; val mode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) { appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) } else { appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) }; return mode == android.app.AppOpsManager.MODE_ALLOWED; }
    fun checkBatteryOpt(ctx: Context = context): Boolean { val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager; return pm.isIgnoringBatteryOptimizations(ctx.packageName); }
    fun checkNotification(ctx: Context = context): Boolean { return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) { androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED } else { true } }
    fun checkForegroundService(ctx: Context = context): Boolean { return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) { androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.FOREGROUND_SERVICE) == android.content.pm.PackageManager.PERMISSION_GRANTED } else { true } }
    private fun startAppUsagePolling() {
        usagePollingJob = CoroutineScope(Dispatchers.Default).launch {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            while (true) {
                val targetApp = _activeSchedule.value?.targetAppPackage
                if (targetApp != null) {
                    val time = System.currentTimeMillis()
                    val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 10000, time)
                    isTargetAppForeground = stats?.any { 
                        it.packageName == targetApp && it.lastTimeUsed > time - 5000 
                    } == true
                    checkConditionsAndToggleTimer()
                }
                delay(2000)
            }
        }
    }
}
