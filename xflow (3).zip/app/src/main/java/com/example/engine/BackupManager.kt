package com.example.engine

import android.content.Context
import android.net.Uri
import com.example.data.Schedule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {
    const val BACKUP_VERSION = 1
    const val DATABASE_VERSION = 1

    data class BackupInfo(
        val backupName: String,
        val backupDate: String,
        val appVersion: String,
        val databaseVersion: Int,
        val backupSize: Long
    )

    fun createBackupJson(schedules: List<Schedule>, appVersion: String): String {
        val root = JSONObject()
        root.put("backupVersion", BACKUP_VERSION)
        root.put("databaseVersion", DATABASE_VERSION)
        root.put("appVersion", appVersion)
        
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        root.put("backupDate", dateFormat.format(Date()))
        
        val schedulesArray = JSONArray()
        for (schedule in schedules) {
            val sObj = JSONObject()
            sObj.put("id", schedule.id)
            sObj.put("subject", schedule.subject)
            sObj.put("description", schedule.description)
            sObj.put("totalTimeSeconds", schedule.totalTimeSeconds)
            sObj.put("timeCompletedSeconds", schedule.timeCompletedSeconds)
            sObj.put("isOnlineMode", schedule.isOnlineMode)
            sObj.put("targetAppPackage", schedule.targetAppPackage ?: JSONObject.NULL)
            sObj.put("status", schedule.status)
            sObj.put("createdAt", schedule.createdAt)
            schedulesArray.put(sObj)
        }
        
        root.put("schedules", schedulesArray)
        return root.toString(2)
    }

    fun parseBackup(jsonString: String): List<Schedule>? {
        try {
            val root = JSONObject(jsonString)
            
            if (!root.has("backupVersion") || !root.has("databaseVersion") || !root.has("schedules")) {
                return null
            }
            
            val schedulesArray = root.getJSONArray("schedules")
            val result = mutableListOf<Schedule>()
            
            for (i in 0 until schedulesArray.length()) {
                val sObj = schedulesArray.getJSONObject(i)
                val schedule = Schedule(
                    id = sObj.optInt("id", 0),
                    subject = sObj.getString("subject"),
                    description = sObj.getString("description"),
                    totalTimeSeconds = sObj.getLong("totalTimeSeconds"),
                    timeCompletedSeconds = sObj.optLong("timeCompletedSeconds", 0L),
                    isOnlineMode = sObj.getBoolean("isOnlineMode"),
                    targetAppPackage = if (sObj.isNull("targetAppPackage")) null else sObj.getString("targetAppPackage"),
                    status = sObj.optString("status", "Upcoming"),
                    createdAt = sObj.optLong("createdAt", System.currentTimeMillis())
                )
                result.add(schedule)
            }
            return result
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    suspend fun readBackupInfo(context: Context, uri: Uri): BackupInfo? {
        return withContext(Dispatchers.IO) {
            try {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return@withContext null
                val size = pfd.statSize
                pfd.close()
                
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val reader = InputStreamReader(stream)
                    val jsonString = reader.readText()
                    val root = JSONObject(jsonString)
                    
                    if (!root.has("backupVersion")) return@withContext null
                    
                    BackupInfo(
                        backupName = uri.lastPathSegment ?: "backup.json",
                        backupDate = root.optString("backupDate", "Unknown"),
                        appVersion = root.optString("appVersion", "Unknown"),
                        databaseVersion = root.optInt("databaseVersion", 1),
                        backupSize = size
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun readSchedulesFromUri(context: Context, uri: Uri): List<Schedule>? {
        return withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val reader = InputStreamReader(stream)
                    val jsonString = reader.readText()
                    parseBackup(jsonString)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun writeBackupToUri(context: Context, uri: Uri, jsonString: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(jsonString.toByteArray(Charsets.UTF_8))
                }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
