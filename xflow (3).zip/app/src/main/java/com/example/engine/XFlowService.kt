package com.example.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.Schedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class XFlowService : Service() {
    companion object {
        const val CHANNEL_ID = "XFlowServiceChannel"
        const val RESULT_CHANNEL_ID = "XFlowResultChannel"
        const val NOTIFICATION_ID = 1

        fun startService(context: Context) {
            val intent = Intent(context, XFlowService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, XFlowService::class.java)
            context.stopService(intent)
        }

        fun showCompletionNotification(context: Context, schedule: Schedule, result: String, percent: Int) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(RESULT_CHANNEL_ID, "XFlow Results", NotificationManager.IMPORTANCE_HIGH)
                manager.createNotificationChannel(channel)
            }
            
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val title = if (percent >= 100) "Study Completed" else if (percent > 0) "Partial Progress" else "Session Missed"
            
            val totalMins = schedule.totalTimeSeconds / 60
            val compMins = schedule.timeCompletedSeconds / 60
            val remainMins = totalMins - compMins
            
            val text = if (percent >= 100) {
                "Subject: ${schedule.subject} | Total Study Time: ${totalMins}m | $percent% Completed"
            } else if (percent > 0) {
                "Studied: ${compMins}m | Remaining: ${remainMins}m | $percent% Completed"
            } else {
                "Subject: ${schedule.subject} | No study time recorded"
            }
            
            val notification = NotificationCompat.Builder(context, RESULT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(com.example.R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()
                
            manager.notify(System.currentTimeMillis().toInt(), notification)
        }
        
        fun showUpcomingNotification(context: Context, schedule: Schedule) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(RESULT_CHANNEL_ID, "XFlow Results", NotificationManager.IMPORTANCE_HIGH)
                manager.createNotificationChannel(channel)
            }
            
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val notification = NotificationCompat.Builder(context, RESULT_CHANNEL_ID)
                .setContentTitle("Upcoming Schedule")
                .setContentText("Your study session starts soon: ${schedule.subject}")
                .setSmallIcon(com.example.R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()
                
            manager.notify(schedule.id, notification)
        }
    }

    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val initialNotification = buildNotification(null, false, 0)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, initialNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        job?.cancel()
        job = CoroutineScope(Dispatchers.Main).launch {
            combine(
                XFlowEngine.activeSchedule,
                XFlowEngine.isTimerRunning,
                XFlowEngine.timeRemainingSeconds
            ) { schedule, isRunning, remaining ->
                Triple(schedule, isRunning, remaining)
            }.collect { (schedule, isRunning, remaining) ->
                val notification = buildNotification(schedule, isRunning, remaining)
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, notification)
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        job?.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "XFlow Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    private fun buildNotification(schedule: Schedule?, isRunning: Boolean, timeRemaining: Long): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)

        if (schedule == null) {
            builder.setContentTitle("XFlow")
            builder.setContentText("No active schedule")
            return builder.build()
        }

        val hasUsageAccess = XFlowEngine.checkUsageAccess(this)
        
        if (schedule.isOnlineMode && !hasUsageAccess) {
            val settingsIntent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            val settingsPendingIntent = PendingIntent.getActivity(
                this, 1, settingsIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.setContentTitle("Usage Access Required")
            builder.setContentText("Tap to open Permission Settings")
            builder.addAction(0, "Open Settings", settingsPendingIntent)
            return builder.build()
        }

        val title = if (isRunning) "Running: ${schedule.subject}" else if (schedule.status == "Paused") "Study Paused" else "Study Ready"
        val totalSeconds = schedule.totalTimeSeconds
        val completedSeconds = totalSeconds - timeRemaining
        val percent = if (totalSeconds > 0) ((completedSeconds.toFloat() / totalSeconds) * 100).toInt() else 0
        
        val hrs = timeRemaining / 3600
        val mins = (timeRemaining % 3600) / 60
        val secs = timeRemaining % 60
        val timeStr = if (hrs > 0) String.format("%02d:%02d:%02d", hrs, mins, secs) else String.format("%02d:%02d", mins, secs)

        val modeStr = if (schedule.isOnlineMode) "Online" else "Offline"
        
        val text = if (isRunning) {
            "Timer: $timeStr | Mode: $modeStr | Progress: $percent%"
        } else if (schedule.status == "Paused") {
            "Resume when study conditions are restored"
        } else {
            "Ready to start | Mode: $modeStr"
        }

        builder.setContentTitle(title)
        builder.setContentText(text)

        return builder.build()
    }
}
