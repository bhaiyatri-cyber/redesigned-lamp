package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Background = Color(0xFF050505)
val Surface = Color(0xFF111111)
val SurfaceVariant = Color(0xFF121212)
val SurfaceEnd = Color(0xFF0A0A0A)
val Accent = Color(0xFF7DD3FC)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val BorderColor = Color(0x1AFFFFFF) // white/10
val BorderColorLight = Color(0x0DFFFFFF) // white/5
val Black = Color(0xFF000000)

