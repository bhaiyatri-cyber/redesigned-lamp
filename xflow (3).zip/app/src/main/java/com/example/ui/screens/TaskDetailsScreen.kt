package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.data.Schedule
import com.example.engine.XFlowEngine
import com.example.ui.theme.Accent
import com.example.ui.theme.Background
import com.example.ui.theme.Surface
import com.example.ui.theme.SurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.BorderColorLight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TaskDetailsScreen(navController: NavController, scheduleId: Int) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var schedule by remember { mutableStateOf<Schedule?>(null) }
    val scope = rememberCoroutineScope()
    
    val activeSchedule by XFlowEngine.activeSchedule.collectAsState()
    val isTimerRunning by XFlowEngine.isTimerRunning.collectAsState()
    val timeRemaining by XFlowEngine.timeRemainingSeconds.collectAsState()
    
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showDuplicateDialog by remember { mutableStateOf(false) }



    var isLoading by remember { mutableStateOf(true) }
    
    LaunchedEffect(scheduleId, activeSchedule) {
        if (activeSchedule?.id == scheduleId) {
            schedule = activeSchedule
            isLoading = false
        } else {
            withContext(Dispatchers.IO) {
                schedule = db.scheduleDao().getScheduleById(scheduleId)
            }
            isLoading = false
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize().background(Background), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
        return
    }

    if (schedule == null) {
        Box(modifier = Modifier.fillMaxSize().background(Background).padding(24.dp), contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Surface),
                elevation = CardDefaults.cardElevation(0.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColorLight)
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Warning, contentDescription = null, tint = Accent, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Schedule Not Found", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("The requested session could not be loaded or may have been deleted.", color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { navController.popBackStack() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background)
                    ) {
                        Text("Go Back", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        return
    }

    val s = schedule!!
    val isActive = activeSchedule?.id == s.id
    
    val totalMins = s.totalTimeSeconds / 60
    val currentCompletedSeconds = if (isActive) {
        s.totalTimeSeconds - timeRemaining
    } else {
        s.timeCompletedSeconds
    }
    val compMins = currentCompletedSeconds / 60
    val percent = if (s.totalTimeSeconds > 0) (currentCompletedSeconds.toFloat() / s.totalTimeSeconds * 100).toInt() else 0
    val remainingSecs = if (isActive) timeRemaining else (s.totalTimeSeconds - s.timeCompletedSeconds)
    
    val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    val createdStr = dateFormat.format(Date(s.createdAt))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(24.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Task Details", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Surface),
            elevation = CardDefaults.cardElevation(0.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColorLight)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(s.subject, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Accent)
                Spacer(modifier = Modifier.height(8.dp))
                Text(s.description.ifEmpty { "No description" }, fontSize = 16.sp, color = TextSecondary)
                
                Spacer(modifier = Modifier.height(24.dp))
                
                                                DetailRow("Status", s.status)
                DetailRow("Study Mode", if (s.isOnlineMode) "Online" else "Offline")
                if (s.isOnlineMode) {
                    DetailRow("Target App", s.targetAppPackage ?: "None")
                }
                
                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = Color(0x20FFFFFF))
                
                DetailRow("Studied", "${compMins}m")
                DetailRow("Remaining", "${remainingSecs / 60}m")
                DetailRow("Completion", "$percent%")
                
                val finalResult = when {
                    isActive -> "Running"
                    s.status in listOf("Upcoming", "Waiting", "Paused") -> "N/A"
                    else -> s.status
                }
                DetailRow("Result", finalResult)
                
                if (!isActive && s.status !in listOf("Upcoming", "Waiting", "Paused")) {
                    val message = when (s.status) {
                        "Completed" -> "Perfect session!"
                        "Almost Completed" -> "So close!"
                        "Good Progress" -> "Solid effort."
                        "Partial Progress" -> "A fair start."
                        "Low Progress" -> "Needs more focus."
                        else -> "Session missed."
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceVariant).padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(message, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Actions
        when (s.status) {
            "Upcoming", "Waiting" -> {
                Button(
                    onClick = { XFlowEngine.startSchedule(s) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Start", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showEditDialog = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Edit", color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Delete", color = Color.Red)
                }
            }
            "Running", "Paused" -> {
                if (s.status == "Running") {
                    Button(
                        onClick = { /* Engine handles pause based on sensor/app state */ },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Pause", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                    }
                } else {
                    Button(
                        onClick = { /* Engine handles resume */ },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Resume", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Background)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { XFlowEngine.stopSchedule() },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Stop", color = Color.Red)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { 
                        scope.launch(Dispatchers.IO) {
                            XFlowEngine.stopSchedule()
                            val skipped = s.copy(status = "Skipped", timeCompletedSeconds = currentCompletedSeconds)
                            db.scheduleDao().updateSchedule(skipped)
                            schedule = skipped
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Skip", color = TextPrimary)
                }
            }
            "Completed", "Partial Progress", "Missed", "Skipped" -> {
                Button(
                    onClick = { /* View Only */ },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("View Only", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showDuplicateDialog = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Duplicate", color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Delete", color = Color.Red)
                }
            }
        }
        
        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Confirm Delete", color = TextPrimary) },
                text = { Text("Are you sure you want to delete this schedule?", color = TextSecondary) },
                containerColor = Surface,
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            if (isActive) XFlowEngine.stopSchedule()
                            db.scheduleDao().deleteSchedule(s)
                            withContext(Dispatchers.Main) {
                                showDeleteConfirm = false
                                navController.popBackStack()
                            }
                        }
                    }) {
                        Text("Delete", color = Color.Red)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) {
                        Text("Cancel", color = Accent)
                    }
                }
            )
        }

        if (showEditDialog || showDuplicateDialog) {
            EditScheduleDialog(
                schedule = s,
                isDuplicate = showDuplicateDialog,
                onDismiss = {
                    showEditDialog = false
                    showDuplicateDialog = false
                },
                onSave = { updatedSchedule ->
                    scope.launch(Dispatchers.IO) {
                        if (showDuplicateDialog) {
                            db.scheduleDao().insertSchedule(updatedSchedule.copy(id = 0, status = "Upcoming", timeCompletedSeconds = 0, createdAt = System.currentTimeMillis()))
                            withContext(Dispatchers.Main) {
                                showDuplicateDialog = false
                                navController.popBackStack()
                            }
                        } else {
                            db.scheduleDao().updateSchedule(updatedSchedule)
                            withContext(Dispatchers.Main) {
                                schedule = updatedSchedule
                                showEditDialog = false
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun EditScheduleDialog(schedule: Schedule, isDuplicate: Boolean, onDismiss: () -> Unit, onSave: (Schedule) -> Unit) {
    var subject by remember { mutableStateOf(schedule.subject) }
    var description by remember { mutableStateOf(schedule.description) }
    var timeMinutes by remember { mutableStateOf((schedule.totalTimeSeconds / 60).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isDuplicate) "Duplicate Schedule" else "Edit Schedule", color = TextPrimary) },
        containerColor = Surface,
        text = {
            Column {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = timeMinutes,
                    onValueChange = { timeMinutes = it },
                    label = { Text("Time (minutes)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val mins = timeMinutes.toLongOrNull() ?: (schedule.totalTimeSeconds / 60)
                onSave(schedule.copy(subject = subject, description = description, totalTimeSeconds = mins * 60))
            }) {
                Text("Save", color = Accent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 14.sp)
        Text(value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
