import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

replacement = """
                Column(modifier = Modifier.weight(1f)) {
                    Text(schedule.subject, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                    if (schedule.status !in listOf("Upcoming", "Waiting", "Running", "Paused")) {
                        val remainingMins = totalMins - compMins
                        Text("Studied: ${compMins}m | Remaining: ${remainingMins}m", fontSize = 12.sp, color = TextSecondary)
                        Text("Completion: $percent% | Result: ${schedule.status}", fontSize = 12.sp, color = Accent)
                    } else if (schedule.status == "Paused") {
                        val remainingMins = totalMins - compMins
                        Text("${schedule.status} • $compMins min done, $remainingMins min left ($percent%)", fontSize = 12.sp, color = TextSecondary)
                    } else {
                        Text("${schedule.status} • $compMins / $totalMins mins", fontSize = 12.sp, color = TextSecondary)
                    }
                }
"""

idx_start = content.find('Column(modifier = Modifier.weight(1f)) {')
idx_end = content.find('}\n            }\n        }\n    }\n}', idx_start)
if idx_end != -1:
    idx_end += 1 # include the closing brace

if idx_start != -1 and idx_end != -1:
    content = content[:idx_start] + replacement.strip() + "\n" + content[idx_end:]
    
with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
