import re

content = """package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.AppDatabase
import com.example.data.Schedule
import com.example.engine.XFlowEngine
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    val schedules by db.scheduleDao().getAllSchedules().collectAsState(initial = emptyList())
    
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasUsageAccess by remember { mutableStateOf(XFlowEngine.checkUsageAccess(context)) }
    var isIgnoringBattery by remember { mutableStateOf(XFlowEngine.checkBatteryOpt(context)) }
    var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }
    var hasForeground by remember { mutableStateOf(XFlowEngine.checkForegroundService(context)) }
    
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = XFlowEngine.checkUsageAccess(context)
                isIgnoringBattery = XFlowEngine.checkBatteryOpt(context)
                hasNotification = XFlowEngine.checkNotification(context)
                hasForeground = XFlowEngine.checkForegroundService(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    
    val activeSchedule by XFlowEngine.activeSchedule.collectAsState()
    val isTimerRunning by XFlowEngine.isTimerRunning.collectAsState()
    val timeRemaining by XFlowEngine.timeRemainingSeconds.collectAsState()
    
    val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification, hasForeground) {
        if (activeSchedule != null) {
            if (activeSchedule?.isOnlineMode == true && !hasUsageAccess) "Usage Access"
            else if (!isIgnoringBattery) "Battery Optimization"
            else if (!hasForeground) "Foreground Service"
            else if (!hasNotification) "Notification"
            else null
        } else null
    }

    val todayStart = remember {
        java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    
    val todayCompletedSeconds = schedules.filter { it.createdAt >= todayStart }.sumOf { it.timeCompletedSeconds }
    val lifetimeCompletedSeconds = schedules.sumOf { it.timeCompletedSeconds }
    
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("create_schedule") },
                containerColor = Accent,
                contentColor = Color.Black,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.size(64.dp).padding(4.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Schedule", modifier = Modifier.size(32.dp))
            }
        },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface)
                            .border(1.dp, BorderColor, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = androidx.compose.ui.res.painterResource(com.example.R.drawable.ic_launcher_foreground),
                            contentDescription = "XFlow Logo",
                            modifier = Modifier.size(24.dp),
                            tint = androidx.compose.ui.graphics.Color.Unspecified
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("XFlow", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                IconButton(
                    onClick = { navController.navigate("settings") },
                    modifier = Modifier.size(44.dp).background(Color(0x0DFFFFFF), RoundedCornerShape(22.dp))
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextPrimary)
                }
            }

            if (missingPermission != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${missingPermission} Required", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Schedule paused until granted.", color = TextSecondary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = { navController.navigate("settings") },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Grant Permission", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
            
            if (schedules.isEmpty()) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            title = "Today Hours",
                            value = formatHoursString(todayCompletedSeconds),
                            label = "HRS",
                            modifier = Modifier.width(160.dp)
                        )
                        StatCard(
                            title = "Lifetime",
                            value = formatHoursString(lifetimeCompletedSeconds),
                            label = "TOT",
                            modifier = Modifier.width(160.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Box(
                        modifier = Modifier.fillMaxSize().weight(1f).padding(horizontal = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No schedules yet.\\nTap + to create a premium flow.",
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                                .padding(horizontal = 24.dp)
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatCard(
                                title = "Today Hours",
                                value = formatHoursString(todayCompletedSeconds),
                                label = "HRS",
                                modifier = Modifier.width(160.dp)
                            )
                            StatCard(
                                title = "Lifetime",
                                value = formatHoursString(lifetimeCompletedSeconds),
                                label = "TOT",
                                modifier = Modifier.width(160.dp)
                            )
                        }
                    }
                    items(schedules.sortedByDescending { it.createdAt }) { schedule ->
                        Box(modifier = Modifier.padding(horizontal = 24.dp)) {
                            val isActive = activeSchedule?.id == schedule.id
                            val displaySchedule = if (isActive && activeSchedule != null) activeSchedule!! else schedule
                            ScheduleCard(
                                schedule = displaySchedule,
                                isActive = isActive,
                                isTimerRunning = isTimerRunning,
                                timeRemaining = if (isActive) timeRemaining else 0,
                                onClick = {
                                    navController.navigate("task_details/${displaySchedule.id}")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(128.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(SurfaceVariant, SurfaceEnd)))
            .border(1.dp, BorderColorLight, RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextTertiary, letterSpacing = 1.5.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 30.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text(label, fontSize = 12.sp, color = Accent, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}

@Composable
fun ScheduleCard(
    schedule: Schedule,
    isActive: Boolean,
    isTimerRunning: Boolean,
    timeRemaining: Long,
    onClick: () -> Unit
) {
    val totalMins = schedule.totalTimeSeconds / 60
    val currentCompletedSeconds = if (isActive) {
        schedule.totalTimeSeconds - timeRemaining
    } else {
        schedule.timeCompletedSeconds
    }
    val compMins = currentCompletedSeconds / 60
    val percent = if (schedule.totalTimeSeconds > 0) (currentCompletedSeconds.toFloat() / schedule.totalTimeSeconds * 100).toInt() else 0

    if (isActive) {
        Column(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Current Session", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Accent))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("CENTRAL ENGINE ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(32.dp))
                    .background(Surface)
                    .border(1.dp, BorderColor, RoundedCornerShape(32.dp))
                    .clickable { onClick() }
                    .padding(24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(schedule.subject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(schedule.description, fontSize = 14.sp, color = TextSecondary)
                        }
                        Box(
                            modifier = Modifier
                                .background(Accent.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                                .border(1.dp, Accent.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(if (schedule.isOnlineMode) "ONLINE MODE" else "OFFLINE MODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x0DFFFFFF))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(percent / 100f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Accent)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("$percent%", fontSize = 14.sp, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Column {
                            Text("STATUS", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(schedule.status.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Accent)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("TIME LEFT", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.5.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(formatTimeFull(timeRemaining), fontSize = 24.sp, fontWeight = FontWeight.Light, color = TextPrimary)
                        }
                    }
                }
            }
        }
    } else {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceEnd)
                .border(1.dp, BorderColorLight, RoundedCornerShape(16.dp))
                .clickable { onClick() }
                .padding(16.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).border(1.dp, BorderColor, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(schedule.subject.take(1).uppercase(), fontSize = 16.sp, color = TextTertiary)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(schedule.subject, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                    if (schedule.status !in listOf("Upcoming", "Waiting", "Running", "Paused")) {
                        val remainingMins = totalMins - compMins
                        Text("Studied: ${compMins}m | Remaining: ${remainingMins}m", fontSize = 12.sp, color = TextSecondary)
                        Text("Completion: $percent% | Result: ${schedule.status}", fontSize = 12.sp, color = Accent)
                    } else if (schedule.status == "Paused") {
                        val remainingMins = totalMins - compMins
                        Text("${schedule.status} • $compMins min done, $remainingMins min left ($percent%)", fontSize = 12.sp, color = TextSecondary)
                    } else {
                        Text("${schedule.status} • $compMins / $totalMins mins", fontSize = 12.sp, color = TextSecondary)
                    }
                }
            }
        }
    }
}

fun formatTimeFull(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

fun formatHoursString(seconds: Long): String {
    val h = seconds / 3600f
    return String.format("%.2f", h)
}
"""

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
