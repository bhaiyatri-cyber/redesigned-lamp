sed -i '/val timeRemaining/a \
    val missingPermission = remember(activeSchedule, hasUsageAccess, isIgnoringBattery, hasNotification) {\
        if (activeSchedule != null) {\
            if (activeSchedule?.isOnlineMode == true && !hasUsageAccess) "Usage Access"\
            else if (!isIgnoringBattery) "Battery Optimization"\
            else if (!hasNotification) "Notification"\
            else null\
        } else null\
    }\
' app/src/main/java/com/example/ui/screens/HomeScreen.kt
