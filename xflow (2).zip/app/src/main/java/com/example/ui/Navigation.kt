package com.example.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.TaskDetailsScreen

@Composable
fun XFlowApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
        composable("create_schedule") { ScheduleScreen(navController) }
        composable("task_details/{scheduleId}") { backStackEntry ->
            val scheduleId = backStackEntry.arguments?.getString("scheduleId")?.toIntOrNull() ?: 0
            TaskDetailsScreen(navController = navController, scheduleId = scheduleId)
        }
    }
}
