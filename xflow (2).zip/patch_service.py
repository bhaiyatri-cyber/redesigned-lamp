import re

with open('app/src/main/java/com/example/engine/XFlowService.kt', 'r') as f:
    content = f.read()

new_func = """        fun stopService(context: Context) {
            val intent = Intent(context, XFlowService::class.java)
            context.stopService(intent)
        }

        fun showCompletionNotification(context: Context, subject: String, result: String, percent: Int) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel("XFlowResultChannel", "XFlow Results", NotificationManager.IMPORTANCE_DEFAULT)
                manager.createNotificationChannel(channel)
            }
            
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val notification = NotificationCompat.Builder(context, "XFlowResultChannel")
                .setContentTitle("Session Ended: $subject")
                .setContentText("Result: $result ($percent% Completed)")
                .setSmallIcon(android.R.drawable.ic_notification_overlay)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()
                
            manager.notify(2, notification)
        }"""

content = content.replace('        fun stopService(context: Context) {\n            val intent = Intent(context, XFlowService::class.java)\n            context.stopService(intent)\n        }', new_func)

with open('app/src/main/java/com/example/engine/XFlowService.kt', 'w') as f:
    f.write(content)
