package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavController
import com.example.engine.XFlowEngine
import com.example.ui.theme.*
import com.example.ui.theme.Dimensions

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasUsageAccess by remember { mutableStateOf(XFlowEngine.checkUsageAccess(context)) }
    var isIgnoringBattery by remember { mutableStateOf(XFlowEngine.checkBatteryOpt(context)) }
    var hasNotification by remember { mutableStateOf(XFlowEngine.checkNotification(context)) }
    var hasForeground by remember { mutableStateOf(XFlowEngine.checkForegroundService(context)) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = XFlowEngine.checkUsageAccess(context)
                isIgnoringBattery = XFlowEngine.checkBatteryOpt(context)
                hasNotification = XFlowEngine.checkNotification(context)
                hasForeground = XFlowEngine.checkForegroundService(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Background,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(Dimensions.paddingMedium)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Permissions", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Accent)
            Spacer(modifier = Modifier.height(16.dp))
            
            PermissionCard(
                title = "Notification",
                description = "Required to show active timer in status bar.",
                isGranted = hasNotification,
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        context.startActivity(intent)
                    } else {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.parse("package:${context.packageName}")
                        context.startActivity(intent)
                    }
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            PermissionCard(
                title = "Usage Access",
                description = "Required for Online Mode to track active apps.",
                isGranted = hasUsageAccess,
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            )
            Spacer(modifier = Modifier.height(16.dp))

            PermissionCard(
                title = "Foreground Service",
                description = "Required to keep timer running in background.",
                isGranted = hasForeground,
                onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    intent.data = Uri.parse("package:${context.packageName}")
                    context.startActivity(intent)
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            PermissionCard(
                title = "Battery Optimization",
                description = "Required to prevent Android from killing the timer.",
                isGranted = isIgnoringBattery,
                onClick = {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    context.startActivity(intent)
                }
            )
                        Spacer(modifier = Modifier.height(40.dp))
            Text("App Details", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Accent)
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Surface)
                        .border(1.dp, BorderColor, RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = androidx.compose.ui.res.painterResource(com.example.R.drawable.ic_x_logo),
                        contentDescription = "XFlow Logo",
                        modifier = Modifier.size(40.dp),
                        tint = Color.Unspecified
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("XFlow", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Version 1.0.8", fontSize = 14.sp, color = TextSecondary)
                }
            }
            
            Spacer(modifier = Modifier.height(Dimensions.paddingMedium))
            Text("Build: 1.0.8", color = TextSecondary, fontSize = 14.sp)
            Text("Engine Version: XFlowCoreEngine v1.0", color = TextSecondary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "About: XFlow is a premium, offline-first study companion designed for absolute focus.",
                color = TextTertiary,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun PermissionCard(title: String, description: String, isGranted: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColorLight)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (isGranted) "Granted" else "Not Granted",
                    color = if (isGranted) Color(0xFF4CAF50) else Color(0xFFF44336),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(description, color = TextSecondary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) SurfaceVariant else Accent,
                    contentColor = if (isGranted) TextPrimary else Background
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(if (isGranted) "Manage" else "Grant Permission", fontWeight = FontWeight.Bold)
            }
        }
    }
}
