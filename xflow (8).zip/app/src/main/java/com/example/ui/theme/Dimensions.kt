package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object Dimensions {
    val paddingSmall: Dp
        @Composable
        get() {
            val config = LocalConfiguration.current
            return if (config.screenWidthDp < 400) 12.dp else if (config.screenWidthDp > 600) 24.dp else 16.dp
        }

    val paddingMedium: Dp
        @Composable
        get() {
            val config = LocalConfiguration.current
            return if (config.screenWidthDp < 400) 16.dp else if (config.screenWidthDp > 600) 32.dp else 24.dp
        }
        
    val paddingLarge: Dp
        @Composable
        get() {
            val config = LocalConfiguration.current
            return if (config.screenWidthDp < 400) 24.dp else if (config.screenWidthDp > 600) 48.dp else 32.dp
        }
}
